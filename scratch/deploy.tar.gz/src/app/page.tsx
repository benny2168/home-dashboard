import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { Dashboard } from "@/components/Dashboard";
import { redirect } from "next/navigation";

export const dynamic = 'force-dynamic';

export default async function Home() {
  const session = await auth();

  if (!session?.user) {
    redirect("/login");
  }

  const userId = (session.user as any)?.id;
  const isAdmin = (session.user as any)?.isAdmin;
  const userDepartment = session.user?.department;

  // Persistent User Avatar Color logic
  let dbUser = await prisma.user.findUnique({
    where: { id: userId },
    select: { avatarColor: true }
  });

  if (dbUser && !dbUser.avatarColor) {
     const colors = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8", "#F7DC6F", "#BB8FCE", "#82E0AA", "#F1948A"];
     const randomColor = colors[Math.floor(Math.random() * colors.length)];
     await prisma.user.update({
        where: { id: userId },
        data: { avatarColor: randomColor }
     });
     dbUser.avatarColor = randomColor;
  }
  const avatarColor = dbUser?.avatarColor || "#3b82f6";

  // Fetch all tabs with sections via the new M2M join, including their themes
  const [tabs, activeTheme, globalSettings, libraryTabs, librarySections] = await Promise.all([
    prisma.tab.findMany({
      orderBy: { order: "asc" },
      include: {
        theme: true,
        allowedUsers: { select: { id: true } },
        editors: { select: { id: true } },
        owners: { select: { id: true } },
        tabSections: {
          orderBy: { order: "asc" },
          include: {
            section: {
              include: {
                bookmarks: { orderBy: { order: "asc" } },
                allowedUsers: { select: { id: true } },
                editors: { select: { id: true } },
              },
            },
          },
        },
      } as any,
    }),
    prisma.theme.findFirst({ where: { isActive: true } }),
    (prisma as any).globalSettings.findUnique({ where: { id: "global" } }),
    prisma.tab.findMany({
      where: { 
        isLibraryItem: true, 
        OR: [
          { organization: null },
          { organization: userDepartment || undefined }
        ]
      },
      include: { theme: true }
    }),
    prisma.section.findMany({
      where: { 
        isLibraryItem: true,
        OR: [
          { organization: null },
          { organization: userDepartment || undefined }
        ]
      },
      include: { bookmarks: true }
    })
  ]);

  // Filter sections based on visibility for non-admins and reshape to the expected prop shape
  const shapedTabs = tabs.map((tab: any) => {
    const visibleSections = tab.tabSections
      .filter((ts: any) => {
        const section = ts.section;
        if (isAdmin) return true;
        if (section.isGlobal) return true;
        if (tab.allowedUsers?.some((u: any) => u.id === userId)) return true;
        if (tab.editors?.some((u: any) => u.id === userId)) return true;
        if (tab.owners?.some((u: any) => u.id === userId)) return true;
        if (section.allowedUsers?.some((u: any) => u.id === userId)) return true;
        if (section.editors?.some((u: any) => u.id === userId)) return true;
        if (section.organization && section.organization === userDepartment) return true;
        return false;
      })
      .map((ts: any) => ({
        ...ts.section,
        column: ts.column,
        height: ts.height,
        tabId: tab.id, // helpful for actions
      }));

    return {
      ...tab,
      sections: visibleSections,
    };
  }).filter((tab: any) => tab.sections.length > 0 || isAdmin);

  if (shapedTabs.length === 0 && !isAdmin) {
    return (
      <div className="glass glass-card text-center" style={{ padding: '4rem 2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600 }}>Welcome to your Dashboard</h2>
        <p style={{ opacity: 0.6, maxWidth: '500px' }}>
          No content has been assigned to you yet. Please contact your administrator.
        </p>
      </div>
    );
  }

  if (shapedTabs.length === 0) {
    return (
      <div className="glass glass-card text-center" style={{ padding: '4rem 2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600 }}>Welcome to your Dashboard</h2>
        <p style={{ opacity: 0.6, maxWidth: '500px' }}>
          It looks like you haven't added any content yet.{' '}
          <span>Head over to the Admin panel to get started.</span>
        </p>
        <a href="/admin" className="btn btn-primary">Go to Admin Panel</a>
      </div>
    );
  }

  return (
    <Dashboard 
      tabs={JSON.parse(JSON.stringify(shapedTabs))} 
      activeTheme={(activeTheme || {
        id: "default",
        name: "Default Blue",
        primaryColor: "#3b82f6",
        backgroundColor: null,
        darkMode: true,
        glassEffect: true,
        dashboardTitle: "Dashboard",
        logoIcon: "LayoutGrid"
      }) as any}
      globalSettings={JSON.parse(JSON.stringify(globalSettings || { logoUrlLight: "", logoUrlDark: "", systemThemeColor: "#3b82f6" }))}
      userDepartment={userDepartment} 
      isAdmin={isAdmin}
      currentUserId={userId}
      userName={session.user.name}
      avatarColor={avatarColor}
      canEditContent={isAdmin || (session.user as any).canEditContent || false}
      iconSize={(session.user as any).iconSize || (activeTheme as any)?.iconSize || 48}
      libraryTabs={JSON.parse(JSON.stringify(libraryTabs || []))}
      librarySections={JSON.parse(JSON.stringify(librarySections || []))}
    />
  );
}
