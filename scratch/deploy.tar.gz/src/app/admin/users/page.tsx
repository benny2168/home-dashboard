import { prisma } from "@/lib/prisma";
import * as actions from "../actions";
import { Shield, ShieldAlert } from "lucide-react";
import Link from "next/link";

export const dynamic = 'force-dynamic';

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    orderBy: { email: "asc" },
    include: {
      allowedTabs: { select: { id: true, title: true } },
      managedTabs: { select: { id: true, title: true } },
      allowedSections: { select: { id: true, title: true } },
      managedSections: { select: { id: true, title: true } },
    }
  }) as any[];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      <div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '0.5rem' }}>User Management</h2>
        <p style={{ opacity: 0.7 }}>Audit user roles and quickly access governance matrices for their assigned content.</p>
      </div>

      <div className="glass glass-card" style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'minmax(250px, 1fr) 140px minmax(200px, 1.5fr) minmax(200px, 1.5fr)', 
          gap: '1rem', 
          padding: '0.75rem 1rem', 
          borderBottom: '1px solid var(--glass-border)',
          fontSize: '0.8rem',
          fontWeight: 700,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          opacity: 0.6
        }}>
          <div>User & Department</div>
          <div>Role Admin</div>
          <div>Workspaces Access</div>
          <div>Sections Access</div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {users.map((user: any) => {
            // Deduplicate tabs & sections between allowed and managed
            const uniqueTabsMap = new Map();
            user.allowedTabs.forEach((t: any) => uniqueTabsMap.set(t.id, { ...t, type: 'viewer' }));
            user.managedTabs.forEach((t: any) => uniqueTabsMap.set(t.id, { ...t, type: 'manager' }));
            const userTabs = Array.from(uniqueTabsMap.values());

            const uniqueSectionsMap = new Map();
            user.allowedSections.forEach((s: any) => uniqueSectionsMap.set(s.id, { ...s, type: 'viewer' }));
            user.managedSections.forEach((s: any) => uniqueSectionsMap.set(s.id, { ...s, type: 'manager' }));
            const userSections = Array.from(uniqueSectionsMap.values());

            return (
              <div key={user.id} style={{ 
                display: 'grid', 
                gridTemplateColumns: 'minmax(250px, 1fr) 140px minmax(200px, 1.5fr) minmax(200px, 1.5fr)', 
                gap: '1rem', 
                padding: '1rem', 
                background: 'rgba(var(--primary-rgb), 0.02)',
                borderRadius: '8px',
                alignItems: 'start'
              }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 600, margin: 0 }}>{user.name || "Unnamed User"}</h3>
                  <p style={{ opacity: 0.6, margin: 0, fontSize: '0.8rem', wordBreak: 'break-all' }}>{user.email}</p>
                  {user.department && (
                    <span style={{ 
                      display: 'inline-block', 
                      marginTop: '0.4rem', 
                      fontSize: '0.75rem', 
                      padding: '0.1rem 0.5rem', 
                      background: 'rgba(var(--text-rgb), 0.1)', 
                      borderRadius: '4px',
                      alignSelf: 'flex-start'
                    }}>
                      {user.department}
                    </span>
                  )}
                </div>

                <div>
                  <form action={async () => {
                    "use server";
                    await actions.toggleUserAdmin(user.id, !user.isAdmin);
                  }}>
                    <button type="submit" className={`btn ${user.isAdmin ? 'btn-primary' : ''}`} style={{ fontSize: '0.75rem', padding: '0.4rem 0.75rem', width: '100%', justifyContent: 'center' }}>
                      {user.isAdmin ? <Shield size={14} /> : <ShieldAlert size={14} style={{ opacity: 0.5 }} />}
                      {user.isAdmin ? 'Admin' : 'Make Admin'}
                    </button>
                  </form>
                </div>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {userTabs.length === 0 ? (
                    <span style={{ fontSize: '0.8rem', opacity: 0.4, fontStyle: 'italic' }}>None explicitly.</span>
                  ) : (
                    userTabs.map((tab: any) => (
                      <Link key={tab.id} href="/admin/tabs" title="Manage in Workspace Hub" style={{
                        fontSize: '0.75rem',
                        padding: '0.2rem 0.5rem',
                        background: tab.type === 'manager' ? 'rgba(var(--primary-rgb), 0.15)' : 'rgba(var(--text-rgb), 0.05)',
                        border: `1px solid ${tab.type === 'manager' ? 'rgba(var(--primary-rgb), 0.3)' : 'var(--glass-border)'}`,
                        borderRadius: '4px',
                        color: 'inherit',
                        textDecoration: 'none',
                        transition: 'all 0.2s',
                        cursor: 'pointer'
                      }}
                      onMouseEnter={(e: any) => e.currentTarget.style.transform = 'translateY(-1px)'}
                      onMouseLeave={(e: any) => e.currentTarget.style.transform = 'translateY(0)'}
                      >
                        {tab.title} {tab.type === 'manager' && " (Mgr)"}
                      </Link>
                    ))
                  )}
                </div>

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                  {userSections.length === 0 ? (
                    <span style={{ fontSize: '0.8rem', opacity: 0.4, fontStyle: 'italic' }}>None explicitly.</span>
                  ) : (
                    userSections.map((section: any) => (
                      <Link key={section.id} href="/admin/sections" title="Manage in Sections Hub" style={{
                        fontSize: '0.75rem',
                        padding: '0.2rem 0.5rem',
                        background: section.type === 'manager' ? 'rgba(var(--primary-rgb), 0.15)' : 'rgba(var(--text-rgb), 0.05)',
                        border: `1px solid ${section.type === 'manager' ? 'rgba(var(--primary-rgb), 0.3)' : 'var(--glass-border)'}`,
                        borderRadius: '4px',
                        color: 'inherit',
                        textDecoration: 'none',
                        transition: 'all 0.2s',
                        cursor: 'pointer'
                      }}
                      onMouseEnter={(e: any) => e.currentTarget.style.transform = 'translateY(-1px)'}
                      onMouseLeave={(e: any) => e.currentTarget.style.transform = 'translateY(0)'}
                      >
                        {section.title} {section.type === 'manager' && " (Mgr)"}
                      </Link>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
