"use client";

import React, { useState, useEffect } from "react";
import { IconComponent } from "@/components/IconPicker";
import * as actions from "@/app/admin/actions";
import { 
  Palette, 
  Search, 
  Plus, 
  X, 
  ChevronRight, 
  Trash2,
  Layers,
  Settings,
  Moon,
  Sun,
  TableProperties,
  LayoutGrid,
  ChevronDown,
  Info,
  Zap,
  ShieldCheck,
  ArrowDownLeft,
  Eye,
  Edit3
} from "lucide-react";

export default function ThemeClient({ 
  initialThemes, 
  globalSettings,
  users = [],
  departments = []
}: { 
  initialThemes: any[], 
  globalSettings: any,
  users?: any[],
  departments?: string[]
}) {
  const [themes, setThemes] = useState(initialThemes);
  const [globalBrand, setGlobalBrand] = useState(globalSettings);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingTheme, setEditingTheme] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "matrix">("grid");
  const [collapsedDepts, setCollapsedDepts] = useState<string[]>([]);
  const [modifiedDepts, setModifiedDepts] = useState<Record<string, string>>({}); // key: dept_themeId

  // Form State
  const [name, setName] = useState("");
  const [primaryColor, setPrimaryColor] = useState("#3b82f6");
  const [backgroundColor, setBackgroundColor] = useState("");
  const [dashboardTitle, setDashboardTitle] = useState("Home Dashboard");
  const [isDark, setIsDark] = useState(true);
  const [glassEffect, setGlassEffect] = useState(true);
  const [backgroundBlur, setBackgroundBlur] = useState(20);
  const [backgroundTint, setBackgroundTint] = useState(0.5);
  const [sectionOpacity, setSectionOpacity] = useState(0.7);
  const [glassOpacity, setGlassOpacity] = useState(0.12);

  const [previewIsDark, setPreviewIsDark] = useState(isDark);
  const [stagedSystemColor, setStagedSystemColor] = useState(globalSettings.systemThemeColor);
  const [isApplyingColor, setIsApplyingColor] = useState(false);

  useEffect(() => {
    setPreviewIsDark(isDark);
  }, [isDark, isModalOpen]);

  // Background Search State
  const [bgSearchText, setBgSearchText] = useState("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchPage, setSearchPage] = useState(1);
  const [activeBgSource, setActiveBgSource] = useState<"search" | "generate" | "upload">("search");
  const [genKeyword, setGenKeyword] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  // Helper for high-contrast text over theme colors
  function getContrastText(hexcolor: string) {
    if (!hexcolor || hexcolor.length < 7) return '#fff';
    const r = parseInt(hexcolor.substring(1, 3), 16);
    const g = parseInt(hexcolor.substring(3, 5), 16);
    const b = parseInt(hexcolor.substring(5, 7), 16);
    const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    if (yiq >= 128) return 'var(--text)';
    return '#fff';
  }

  const searchImages = async (isNew: boolean = true) => {
    if (!bgSearchText) return;
    setIsSearching(true);
    if (isNew) setSearchResults([]);
    const nextPage = isNew ? 1 : searchPage + 1;
    try {
        const q = bgSearchText.toLowerCase();
        const results = Array.from({length: 6}, (_, i) => 
            `https://loremflickr.com/1600/900/${encodeURIComponent(q + ",architecture,modern")}/all?lock=${nextPage * 10 + i + Math.floor(Math.random() * 1000)}`
        );
        if (isNew) {
            setSearchResults(results);
            setSearchPage(1);
        } else {
            setSearchResults(prev => [...prev, ...results]);
            setSearchPage(nextPage);
        }
    } catch (e) {
        console.error(e);
    } finally {
        setIsSearching(false);
    }
  };

  const openAdd = () => {
    setEditingTheme(null);
    setName("");
    setPrimaryColor("#3b82f6");
    setBackgroundColor("");
    setDashboardTitle("Home Dashboard");
    setIsDark(true);
    setGlassEffect(true);
    setBackgroundBlur(20);
    setBackgroundTint(0.5);
    setSectionOpacity(0.7);
    setGlassOpacity(0.12);
    setIsModalOpen(true);
  };

  const openEdit = (theme: any) => {
    setEditingTheme(theme);
    setName(theme.name);
    setPrimaryColor(theme.primaryColor);
    setBackgroundColor(theme.backgroundColor || "");
    setDashboardTitle(theme.dashboardTitle || "Home Dashboard");
    setIsDark(theme.darkMode);
    setGlassEffect(theme.glassEffect);
    setBackgroundBlur(theme.backgroundBlur || 20);
    setBackgroundTint(theme.backgroundTint || 0.5);
    setSectionOpacity(theme.sectionOpacity ?? 0.7);
    setGlassOpacity(theme.glassOpacity ?? 0.12);
    setIsModalOpen(true);
  };

  const save = async () => {
    if (!name) return;
    const data = { 
      name, 
      primaryColor, 
      backgroundColor, 
      dashboardTitle, 
      darkMode: isDark, 
      glassEffect,
      backgroundBlur: Number(backgroundBlur),
      backgroundTint: Number(backgroundTint),
      sectionOpacity: Number(sectionOpacity),
      glassOpacity: Number(glassOpacity)
    };
    if (editingTheme) {
      await actions.updateTheme(editingTheme.id, data);
    } else {
      await actions.createTheme(data);
    }
    window.location.reload();
  };

  const confirmDelete = async () => {
      if (editingTheme) {
          await actions.deleteTheme(editingTheme.id);
          window.location.reload();
      }
  };

  const generateAbstract = async () => {
    if (!genKeyword) return;
    setIsGenerating(true);
    try {
        const canvas = document.createElement('canvas');
        canvas.width = 1600; canvas.height = 900;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const seed = genKeyword.split('').reduce((a,b) => (a << 5) - a + b.charCodeAt(0), 0);
        const rand = (s: number) => {
            const x = Math.sin(s) * 10000;
            return x - Math.floor(x);
        };
        ctx.fillStyle = isDark ? '#0a0a0b' : '#f8fafc';
        ctx.fillRect(0,0,1600,900);
        for(let i=0; i<8; i++) {
            const x = rand(seed + i) * 1600;
            const y = rand(seed + i * 2) * 900;
            const r = 400 + rand(seed + i * 3) * 600;
            const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
            const hue = (seed + i * 40) % 360;
            const alpha = 0.2 + rand(seed + i * 4) * 0.4;
            grad.addColorStop(0, `hsla(${hue}, 70%, 50%, ${alpha})`);
            grad.addColorStop(1, 'transparent');
            ctx.fillStyle = grad;
            ctx.globalCompositeOperation = 'screen';
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI * 2);
            ctx.fill();
        }
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        const physicalUrl = await actions.saveGeneratedImage(dataUrl);
        if (physicalUrl) setBackgroundColor(physicalUrl);
    } catch (e) {
        console.error(e);
    } finally {
        setIsGenerating(false);
    }
  };

  const handleGlobalUpdate = async (field: string, value: any) => {
      if (field === "systemThemeColor") {
         setIsApplyingColor(true);
         // Inject CSS Variables Optimistically for Instant Portal Sync
         document.documentElement.style.setProperty('--primary', value);
         const rgb = hexToRgb(value);
         document.documentElement.style.setProperty('--primary-rgb', rgb);
      }
      const newSettings = { ...globalBrand, [field]: value };
      setGlobalBrand(newSettings);
      try {
         await actions.updateGlobalSettings(newSettings);
      } catch (err) {
         console.error("Global update failed:", err);
      } finally {
         if (field === "systemThemeColor") setIsApplyingColor(false);
      }
  };

  const handleLogoUpload = async (file: File, isDarkLogo: boolean) => {
      const fd = new FormData(); fd.append("file", file);
      const url = await actions.uploadImage(fd);
      if (url) handleGlobalUpdate(isDarkLogo ? "logoUrlDark" : "logoUrlLight", url);
      return url;
  };

  const filteredUsers = users.filter((u: any) => 
    (u.name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
     u.email?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filteredThemes = themes.filter((t: any) => t.name.toLowerCase().includes(searchQuery.toLowerCase()));

  // PREVIEW STYLES
  const previewBg = previewIsDark ? '#0f172a' : '#f1f5f9';
  const previewText = previewIsDark ? '#fff' : '#0f172a';
  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}` : '59, 130, 246';
  };
  const primaryRgb = hexToRgb(primaryColor);
  const previewSectionBg = previewIsDark ? `rgba(15, 23, 42, ${sectionOpacity})` : `rgba(255, 255, 255, ${sectionOpacity})`;
  const previewBookmarkBg = previewIsDark ? `rgba(${primaryRgb}, ${glassOpacity})` : `rgba(255, 255, 255, ${glassOpacity})`;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }}>
       {/* Site Branding */}
       <div className="glass" style={{ padding: '2rem', borderRadius: '24px', background: 'rgba(var(--primary-rgb), 0.03)', border: '1px solid var(--glass-border)', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <Settings size={20} style={{ opacity: 0.5 }} />
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, margin: 0 }}>Site Branding</h2>
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '2rem' }}>
             <div className="field">
                <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '1rem' }}>Light Mode Logo</span>
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                   <div style={{ 
                       width: '140px', height: '80px', borderRadius: '14px', 
                       backgroundColor: '#eef2f7',
                       backgroundImage: `radial-gradient(circle at top left, rgba(${hexToRgb(globalBrand.systemThemeColor)}, 0.15) 0%, transparent 70%)`,
                       display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0.75rem',
                       border: '1px solid rgba(0,0,0,0.05)',
                       position: 'relative', overflow: 'hidden'
                   }}>
                      <img src={globalBrand.logoUrlLight || ""} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', zIndex: 1 }} />
                   </div>
                   <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                      <input type="file" id="logo-light-brand" hidden onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0], false)} />
                      <label htmlFor="logo-light-brand" className="btn" style={{ fontSize: '0.7rem', padding: '0.5rem 1rem', borderRadius: '8px' }}>Replace</label>
                   </div>
                </div>
             </div>

             <div className="field">
                <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '1rem' }}>Dark Mode Logo</span>
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                   <div style={{ 
                       width: '140px', height: '80px', borderRadius: '14px', 
                       backgroundColor: '#050505',
                       backgroundImage: `radial-gradient(circle at top left, rgba(${hexToRgb(globalBrand.systemThemeColor)}, 0.25) 0%, transparent 70%)`,
                       display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0.75rem',
                       border: '1px solid rgba(255,255,255,0.05)',
                       position: 'relative', overflow: 'hidden'
                   }}>
                      <img src={globalBrand.logoUrlDark || ""} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', zIndex: 1 }} />
                   </div>
                   <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                      <input type="file" id="logo-dark-brand" hidden onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0], true)} />
                      <label htmlFor="logo-dark-brand" className="btn" style={{ fontSize: '0.7rem', padding: '0.5rem 1rem', borderRadius: '8px' }}>Replace</label>
                   </div>
                </div>
             </div>

             <div className="field">
                <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '1rem' }}>System Theme Color</span>
                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                    <div style={{ position: 'relative', width: '45px', height: '45px' }}>
                        <input type="color" value={stagedSystemColor} onChange={(e) => setStagedSystemColor(e.target.value)} style={{ width: '100%', height: '100%', padding: '0', border: 'none', background: 'transparent', cursor: 'pointer', borderRadius: '10px', overflow: 'hidden' }} />
                    </div>
                    <input value={stagedSystemColor} onChange={(e) => setStagedSystemColor(e.target.value)} className="glass" style={{ flex: 1, padding: '0.75rem', borderRadius: '10px', fontSize: '0.85rem' }} />
                    
                    {stagedSystemColor !== globalBrand.systemThemeColor && (
                        <button 
                            disabled={isApplyingColor}
                            onClick={() => handleGlobalUpdate("systemThemeColor", stagedSystemColor)}
                            className="btn btn-primary animate-pulse" 
                            style={{ 
                                padding: '0.75rem 1.5rem', 
                                borderRadius: '10px', 
                                border: 'none',
                                fontWeight: 800,
                                fontSize: '0.75rem',
                                color: '#fff',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem',
                                boxShadow: `0 4px 15px rgba(${hexToRgb(stagedSystemColor)}, 0.4)`
                            }}
                        >
                           {isApplyingColor ? 'Syncing...' : 'APPLY'}
                        </button>
                    )}
                </div>
             </div>
          </div>
       </div>

       {/* View Mode & Actions */}
       <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <div style={{ display: 'flex', background: 'rgba(var(--primary-rgb), 0.08)', padding: '0.4rem', borderRadius: '14px', gap: '0.25rem', border: '1px solid var(--glass-border)' }}>
             <button onClick={() => setViewMode("grid")} className="btn" style={{ padding: '0.5rem 1rem', borderRadius: '10px', background: viewMode === "grid" ? 'var(--primary)' : 'transparent', color: viewMode === "grid" ? '#fff' : 'var(--text)', border: 'none', fontSize: '0.85rem', fontWeight: 700, display: 'flex', gap: '0.5rem' }}>
                <LayoutGrid size={18} /> Theme Catalog
             </button>
             <button onClick={() => setViewMode("matrix")} className="btn" style={{ padding: '0.5rem 1rem', borderRadius: '10px', background: viewMode === "matrix" ? 'var(--primary)' : 'transparent', color: viewMode === "matrix" ? '#fff' : 'var(--text)', border: 'none', fontSize: '0.85rem', fontWeight: 700, display: 'flex', gap: '0.5rem' }}>
                <TableProperties size={18} /> Permissions Matrix
             </button>
          </div>
          
          <div className="glass" style={{ flex: 1, position: 'relative' }}>
             <Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', opacity: 0.3 }} />
             <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={`Search ${viewMode === 'grid' ? 'themes' : 'users'}...`} className="glass" style={{ width: '100%', padding: '0.75rem 1rem 0.75rem 3rem', borderRadius: '12px', border: 'none' }} />
          </div>

          <button onClick={openAdd} className="btn btn-primary" style={{ padding: '0.75rem 1.5rem', borderRadius: '12px', fontWeight: 600, display: 'flex', gap: '0.5rem' }}>
             <Plus size={18} /> New Theme
          </button>
       </div>

       {viewMode === "grid" ? (
          <div className="fade-in" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '2rem' }}>
             {filteredThemes.map((theme: any) => (
                <div key={theme.id} className="glass theme-card" style={{ padding: '0', borderRadius: '24px', overflow: 'hidden', border: '1px solid var(--glass-border)', transition: 'all 0.3s ease', position: 'relative' }}>
                    <div className="theme-thumbnail" style={{ height: '160px', background: theme.primaryColor, position: 'relative', overflow: 'hidden' }}>
                        {theme.backgroundColor && <img src={theme.backgroundColor} alt={theme.name} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(2px) brightness(0.7)' }} />}
                        <div style={{ position: 'absolute', inset: 0, background: `linear-gradient(to top, rgba(0,0,0,0.4), transparent)`, zIndex: 1 }} />
                        <div style={{ position: 'absolute', bottom: '1.25rem', left: '1.5rem', zIndex: 2 }}>
                            <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 800, color: '#fff', textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>{theme.name}</h3>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '0.25rem' }}><span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.7)', display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}><Palette size={12} /> {theme.primaryColor}</span></div>
                        </div>
                        <div style={{ position: 'absolute', top: '1rem', right: '1rem', zIndex: 2 }}>
                           <div className="glass" style={{ padding: '0.4rem', borderRadius: '10px', background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.1)' }}>{theme.darkMode ? <Moon size={16} /> : <Sun size={16} />}</div>
                        </div>
                    </div>
                    <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                       <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.75rem' }}>
                           <div className="glass" style={{ padding: '0.6rem', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(var(--primary-rgb), 0.05)' }}>
                               <span style={{ fontSize: '0.7rem', fontWeight: 700 }}>{theme.owners?.length || 1} Owners</span>
                           </div>
                           <div className="glass" style={{ padding: '0.6rem', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(var(--primary-rgb), 0.05)' }}>
                               <Layers size={14} style={{ opacity: 0.4 }} />
                               <span style={{ fontSize: '0.7rem', fontWeight: 700 }}>{theme.tabs?.length || 0} Workspaces</span>
                           </div>
                       </div>
                       <button 
                          onClick={() => openEdit(theme)} 
                          className="btn btn-primary" 
                          style={{ width: '100%', padding: '0.75rem', borderRadius: '12px', fontSize: '0.85rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.05em' }}
                       >
                          Manage Theme
                       </button>
                    </div>
                </div>
             ))}
          </div>
       ) : (
          <div className="fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
             <div className="glass" style={{ padding: '1.25rem 2rem', borderRadius: '16px', display: 'flex', gap: '2.5rem', alignItems: 'center', justifyContent: 'center', border: '1px solid var(--glass-border)' }}>
                <div style={{ fontSize: '0.8rem', fontWeight: 800, textTransform: 'uppercase', opacity: 0.4, letterSpacing: '0.05em' }}>Access Legend:</div>
                <div style={{ display: 'flex', gap: '3.5rem', alignItems: 'center' }}>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                      <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: 'var(--primary)', boxShadow: '0 0 12px rgba(var(--primary-rgb), 0.4)' }} />
                      <span style={{ fontSize: '0.85rem', fontWeight: 800 }}>Owner:</span><span style={{ fontSize: '0.85rem', opacity: 0.6 }}>Design authority</span>
                   </div>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                      <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: 'rgba(var(--primary-rgb), 0.15)', border: '1px solid rgba(var(--primary-rgb), 0.3)' }} />
                      <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Editor:</span><span style={{ fontSize: '0.85rem', opacity: 0.6 }}>Can apply to hubs</span>
                   </div>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                      <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: 'rgba(var(--primary-rgb), 0.05)', border: '1px solid rgba(var(--primary-rgb), 0.1)' }} />
                      <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Viewer:</span><span style={{ fontSize: '0.85rem', opacity: 0.6 }}>Public asset</span>
                   </div>
                </div>
             </div>

             <div className="glass" style={{ padding: '0', borderRadius: '24px', overflowX: 'auto', border: '1px solid var(--glass-border)', boxShadow: '0 10px 30px -10px rgba(0,0,0,0.1)' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', minWidth: '1000px' }}>
                    <thead style={{ background: 'rgba(var(--primary-rgb), 0.06)', borderBottom: '1px solid var(--glass-border)' }}>
                       <tr>
                          <th style={{ padding: '1.25rem 1.5rem', fontSize: '0.85rem', fontWeight: 800, textTransform: 'uppercase', color: 'var(--primary)', width: '1%', whiteSpace: 'nowrap' }}>Identity Registry</th>
                          {themes.map((t: any) => (
                             <th key={t.id} style={{ padding: '1rem 0.25rem', fontSize: '0.75rem', textTransform: 'uppercase', textAlign: 'center', width: '135px' }}>
                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.6rem' }}>
                                   <div style={{ width: '22px', height: '22px', borderRadius: '6px', background: t.primaryColor, border: '2px solid #fff', boxShadow: '0 2px 6px rgba(0,0,0,0.15)' }} />
                                   <span style={{ fontWeight: 800 }}>{t.name}</span>
                                </div>
                             </th>
                          ))}
                       </tr>
                    </thead>
                    <tbody>
                       {departments.map((dept: string) => {
                          const deptUsers = filteredUsers.filter((u: any) => (u.department || "General") === dept);
                          if (deptUsers.length === 0) return null;

                          return (
                             <React.Fragment key={dept}>
                                <tr style={{ background: 'rgba(var(--primary-rgb), 0.04)', borderBottom: '1px solid var(--glass-border)' }}>
                                   <td style={{ padding: '0.85rem 1.25rem' }}>
                                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                         <button onClick={() => setCollapsedDepts(prev => prev.includes(dept) ? prev.filter(d => d !== dept) : [...prev, dept])} style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer', opacity: 0.5, display: 'flex' }}>{collapsedDepts.includes(dept) ? <ChevronRight size={18} /> : <ChevronDown size={18} />}</button>
                                         <span style={{ fontSize: '0.8rem', fontWeight: 800, textTransform: 'uppercase', opacity: 0.8, letterSpacing: '0.05em', color: 'var(--text)' }}>{dept} TEAM</span>
                                         <Info size={14} style={{ opacity: 0.3 }} />
                                      </div>
                                   </td>
                                   {themes.map((t: any) => {
                                      const savedRole = t.departmentAccess?.find((da: any) => da.department === dept)?.role || "none";
                                      const staging = modifiedDepts[`${dept}_${t.id}`];
                                      const display = staging !== undefined ? staging : savedRole;

                                      return (
                                         <td key={t.id} style={{ padding: '0.5rem 0.25rem' }}>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                                               <div style={{ 
                                                   flex: 1,
                                                   borderRadius: '10px', 
                                                   minHeight: '38px',
                                                   background: display === 'owner' ? 'var(--primary)' : (display === 'none' ? 'rgba(var(--primary-rgb), 0.03)' : 'rgba(var(--primary-rgb), 0.1)'),
                                                   border: '1px solid var(--glass-border)',
                                                   display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
                                                   position: 'relative'
                                               }}>
                                                  <span style={{ 
                                                     fontSize: '0.75rem', fontWeight: 800, textTransform: 'uppercase', 
                                                     color: display === 'owner' ? getContrastText(t.primaryColor) : 'var(--text)',
                                                     opacity: display === 'none' ? 0.2 : 1, zIndex: 1
                                                  }}>{display === 'none' ? 'NOT SHARED' : (display.toUpperCase() + ' (DEPT)')}</span>
                                                  <select 
                                                     value={display} 
                                                     onChange={async (e) => {
                                                        const val = e.target.value;
                                                        setModifiedDepts(prev => ({ ...prev, [`${dept}_${t.id}`]: val }));
                                                     }}
                                                     style={{ position: 'absolute', inset: 0, opacity: 0, cursor: 'pointer', width: '100%', zIndex: 2 }}
                                                  >
                                                     <option value="none">Not Shared</option><option value="viewer">Viewer (Dept)</option><option value="editor">Editor (Dept)</option><option value="owner">Owner (Dept)</option>
                                                  </select>
                                               </div>
                                               {modifiedDepts[`${dept}_${t.id}`] && (
                                                   <button 
                                                      onClick={async () => {
                                                         const role = modifiedDepts[`${dept}_${t.id}`];
                                                         await actions.bulkApplyDeptThemeRole(t.id, dept, role);
                                                         
                                                         // Deep Optimistic Update (Header + All Members in Dept)
                                                         setThemes((prevThemes: any[]) => prevThemes.map((theme: any) => {
                                                            if (theme.id !== t.id) return theme;
                                                            const otherAccess = (theme.departmentAccess || []).filter((da: any) => da.department !== dept);
                                                            
                                                            const deptUserIds = deptUsers.map((u: any) => u.id);
                                                            const filterOut = (arr: any[]) => (arr || []).filter((u: any) => !deptUserIds.includes(u.id));
                                                            
                                                            return { 
                                                               ...theme, 
                                                               departmentAccess: role === "none" ? otherAccess : [...otherAccess, { department: dept, role }],
                                                               owners: role === "owner" ? [...filterOut(theme.owners), ...deptUsers] : filterOut(theme.owners),
                                                               editors: role === "editor" ? [...filterOut(theme.editors), ...deptUsers] : filterOut(theme.editors),
                                                               allowedUsers: role === "viewer" ? [...filterOut(theme.allowedUsers), ...deptUsers] : filterOut(theme.allowedUsers)
                                                            };
                                                         }));

                                                         setModifiedDepts(prev => {
                                                            const next = { ...prev };
                                                            delete next[`${dept}_${t.id}`];
                                                            return next;
                                                         });
                                                      }}
                                                      title="Apply to group"
                                                      className="btn-sync"
                                                      style={{ padding: '0.4rem', borderRadius: '8px', background: 'rgba(var(--primary-rgb), 0.1)', color: 'var(--primary)', border: 'none', cursor: 'pointer', display: 'flex', transition: 'all 0.2s ease', position: 'relative', zIndex: 10 }}
                                                   >
                                                      <Zap size={14} />
                                                   </button>
                                                )}
                                            </div>
                                         </td>
                                      );
                                   })}
                                </tr>
                                {!collapsedDepts.includes(dept) && deptUsers.map((u: any) => {
                                   return (
                                     <tr key={u.id} style={{ borderBottom: '1px solid rgba(var(--primary-rgb), 0.03)' }}>
                                        <td style={{ padding: '0.85rem 3rem' }}>
                                           <div style={{ display: 'flex', flexDirection: 'column' }}>
                                              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                                  <span style={{ fontSize: '0.95rem', fontWeight: 600 }}>{u.name || u.email}</span>
                                                  {u.isAdmin && <span style={{ fontSize: '0.6rem', color: '#3b82f6', background: 'rgba(59,130,246,0.1)', padding: '0.1rem 0.3rem', borderRadius: '4px', fontWeight: 800 }}>Admin</span>}
                                              </div>
                                              <span style={{ fontSize: '0.75rem', opacity: 0.4 }}>{u.email}</span>
                                           </div>
                                        </td>
                                        {themes.map((theme: any) => {
                                            const isOwner = theme.owners?.some((o: any) => o.id === u.id);
                                            const isEditor = theme.editors?.some((e: any) => e.id === u.id);
                                            const isViewer = theme.allowedUsers?.some((v: any) => v.id === u.id);
                                            const isBlocked = theme.blockedUsers?.some((b: any) => b.id === u.id);
                                            
                                            const deptRole = theme.departmentAccess?.find((da: any) => da.department === dept)?.role || "none";
                                            const role = isOwner ? 'owner' : (isEditor ? 'editor' : (isViewer ? 'viewer' : (isBlocked ? 'none' : 'inherited')));
                                            const effectiveRole = u.isAdmin ? 'owner' : (role === 'inherited' ? deptRole : role);

                                           return (
                                              <td key={theme.id} style={{ padding: '0.4rem 0.6rem', textAlign: 'center', minWidth: '150px' }}>
                                                 <div style={{ 
                                                     width: '100%', position: 'relative', borderRadius: '10px', overflow: 'hidden', minHeight: '36px',
                                                     border: effectiveRole === "owner" ? '1px solid var(--primary)' : '1px solid rgba(var(--primary-rgb), 0.2)',
                                                     background: u.isAdmin 
                                                        ? 'repeating-linear-gradient(45deg, rgba(var(--primary-rgb), 0.25), rgba(var(--primary-rgb), 0.25) 10px, rgba(var(--primary-rgb), 0.35) 10px, rgba(var(--primary-rgb), 0.35) 20px)'
                                                        : (effectiveRole === "owner" ? 'var(--primary)' : effectiveRole === "editor" ? 'rgba(var(--primary-rgb), 0.12)' : 'rgba(var(--primary-rgb), 0.05)'),
                                                     display: 'flex', alignItems: 'center', justifyContent: 'center'
                                                 }}>
                                                    <div style={{ 
                                                       position: 'absolute', pointerEvents: 'none', 
                                                       color: (effectiveRole === 'owner' && !u.isAdmin) ? getContrastText(theme.primaryColor) : 'var(--text)', 
                                                       fontSize: '0.62rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.02em', whiteSpace: 'nowrap',
                                                       zIndex: 1, display: 'flex', alignItems: 'center', gap: '0.35rem'
                                                    }}>
                                                       {u.isAdmin ? <><ShieldCheck size={11} strokeWidth={3} /> OWNER (ADMIN)</> : (
                                                          role === 'inherited' 
                                                             ? <><ArrowDownLeft size={11} strokeWidth={3} /> INHERITED ({deptRole === 'none' ? 'NOT SHARED' : deptRole.toUpperCase()})</>
                                                             : (
                                                                effectiveRole === 'none' ? <><X size={11} strokeWidth={3} /> NOT SHARED</> : 
                                                                effectiveRole === 'owner' ? <><ShieldCheck size={11} strokeWidth={3} /> OWNER</> :
                                                                effectiveRole === 'editor' ? <><Edit3 size={11} strokeWidth={3} /> EDITOR</> :
                                                                <><Eye size={11} strokeWidth={3} /> VIEWER</>
                                                             )
                                                       )}
                                                    </div>
                                                    {!u.isAdmin && (
                                                       <select 
                                                          value={role}
                                                          onChange={async (e) => {
                                                             const newRole = e.target.value;
                                                             await actions.updateThemeUserRole(theme.id, u.id, newRole);
                                                             
                                                             // Optimistic Update for Individual User
                                                             setThemes((prevThemes: any[]) => prevThemes.map((t: any) => {
                                                                if (t.id !== theme.id) return t;
                                                                return {
                                                                   ...t,
                                                                   owners: newRole === "owner" ? [...(t.owners || []).filter((o: any) => o.id !== u.id), u] : (t.owners || []).filter((o: any) => o.id !== u.id),
                                                                   editors: newRole === "editor" ? [...(t.editors || []).filter((e: any) => e.id !== u.id), u] : (t.editors || []).filter((e: any) => e.id !== u.id),
                                                                   allowedUsers: newRole === "viewer" ? [...(t.allowedUsers || []).filter((a: any) => a.id !== u.id), u] : (t.allowedUsers || []).filter((a: any) => a.id !== u.id),
                                                                   blockedUsers: newRole === "none" ? [...(t.blockedUsers || []).filter((b: any) => b.id !== u.id), u] : (t.blockedUsers || []).filter((b: any) => b.id !== u.id)
                                                                };
                                                             }));
                                                          }}
                                                          style={{ position: 'absolute', inset: 0, opacity: 0, cursor: 'pointer', zIndex: 2 }}
                                                       >
                                                          <option value="inherited">Inherited ({deptRole === 'none' ? 'Not Shared' : deptRole.charAt(0).toUpperCase() + deptRole.slice(1)})</option>
                                                          <option value="viewer">Viewer</option>
                                                          <option value="editor">Editor</option>
                                                          <option value="owner">Owner</option>
                                                          <option value="none">Not Shared</option>
                                                       </select>
                                                    )}
                                                 </div>
                                              </td>
                                           );
                                        })}
                                     </tr>
                                   );
                                })}
                             </React.Fragment>
                          );
                       })}
                    </tbody>
                 </table>
             </div>
          </div>
       )}

       {/* EDIT MODAL */}
       {isModalOpen && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(20px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
             <div className="glass" style={{ width: '100%', maxWidth: '1200px', maxHeight: '95vh', display: 'flex', flexDirection: 'column', borderRadius: '32px', overflow: 'hidden', border: '1px solid rgba(var(--primary-rgb), 0.15)' }}>
                <div style={{ padding: '1.5rem 2.5rem', borderBottom: '1px solid var(--glass-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <Palette size={22} style={{ color: primaryColor }} />
                      <span style={{ fontSize: '1.25rem', fontWeight: 800 }}>{editingTheme ? `Studio: ${editingTheme.name}` : "Manifest New Theme"}</span>
                   </div>
                   <button onClick={() => setIsModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text)', opacity: 0.5 }}><X size={24} /></button>
                </div>

                <div style={{ flex: 1, overflowY: 'auto', padding: '2.5rem', display: 'grid', gridTemplateColumns: 'minmax(450px, 1fr) 420px', gap: '4rem' }}>
                   <div style={{ display: 'flex', flexDirection: 'column', gap: '3rem' }}>
                      <section>
                         <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 800, opacity: 0.4, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '1.5rem' }}>Identity & Primary Branding</label>
                         <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                             <div className="field">
                                 <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '0.75rem' }}>Theme Title</span>
                                 <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Cobalt Nebula" className="glass" style={{ width: '100%', padding: '0.9rem', borderRadius: '12px' }} />
                             </div>
                             <div className="field">
                                 <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '0.75rem' }}>Dashboard Headline</span>
                                 <input value={dashboardTitle} onChange={(e) => setDashboardTitle(e.target.value)} placeholder="Workspace" className="glass" style={{ width: '100%', padding: '0.9rem', borderRadius: '12px' }} />
                             </div>
                             <div className="field" style={{ gridColumn: 'span 2' }}>
                                 <span style={{ fontSize: '0.8rem', opacity: 0.6, display: 'block', marginBottom: '0.75rem' }}>Theme Tint (Primary Color)</span>
                                 <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                                     <input type="color" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} style={{ width: '70px', height: '50px', padding: '0', border: 'none', background: 'transparent', cursor: 'pointer' }} />
                                     <input value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="glass" style={{ flex: 1, padding: '0.8rem', borderRadius: '12px', fontSize: '0.9rem', fontWeight: 700 }} />
                                 </div>
                             </div>
                         </div>
                      </section>

                      <section>
                         <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 800, opacity: 0.4, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '1.5rem' }}>Atmospheric Controls</label>
                         <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                            <div className="field">
                               <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}><span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Crystalline Blur</span><span className="glass" style={{ padding: '0.2rem 0.6rem', borderRadius: '6px', fontSize: '0.75rem', fontWeight: 800 }}>{backgroundBlur}px</span></div>
                               <input type="range" min="0" max="100" value={backgroundBlur} onChange={(e) => setBackgroundBlur(parseInt(e.target.value))} style={{ width: '100%', accentColor: primaryColor }} />
                            </div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                               <div className="field">
                                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}><span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Section Clarity</span></div>
                                  <input type="range" min="0" max="1" step="0.05" value={sectionOpacity} onChange={(e) => setSectionOpacity(parseFloat(e.target.value))} style={{ width: '100%', accentColor: primaryColor }} />
                               </div>
                               <div className="field">
                                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}><span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Glass Bloom</span></div>
                                  <input type="range" min="0" max="1" step="0.01" value={glassOpacity} onChange={(e) => setGlassOpacity(parseFloat(e.target.value))} style={{ width: '100%', accentColor: primaryColor }} />
                               </div>
                            </div>
                         </div>
                      </section>

                      <section>
                         <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
                            <label style={{ fontSize: '0.7rem', fontWeight: 800, opacity: 0.4, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Atmospheric Backdrop</label>
                            <div style={{ display: 'flex', gap: '0.4rem' }}>{(["search", "generate", "upload"] as const).map(src => (<button key={src} onClick={() => setActiveBgSource(src)} className="btn" style={{ fontSize: '0.6rem', padding: '0.3rem 0.6rem', borderRadius: '6px', background: activeBgSource === src ? 'var(--primary)' : 'rgba(var(--primary-rgb), 0.08)', color: activeBgSource === src ? '#fff' : 'var(--text)', border: 'none' }}>{src.toUpperCase()}</button>))}</div>
                         </div>
                         <div className="glass" style={{ padding: '1.5rem', borderRadius: '20px', background: 'rgba(var(--primary-rgb), 0.03)' }}>
                             {activeBgSource === "search" && (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                    <div style={{ position: 'relative' }}><Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', opacity: 0.3 }} /><input value={bgSearchText} onChange={(e) => setBgSearchText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && searchImages(true)} placeholder="Search visual keywords..." className="glass" style={{ width: '100%', padding: '0.8rem 2.8rem', borderRadius: '12px' }} /></div>
                                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem', maxHeight: '180px', overflowY: 'auto' }}>{searchResults.map((url, i) => (<div key={i} onClick={() => setBackgroundColor(url)} className="glass" style={{ aspectRatio: '16/9', cursor: 'pointer', overflow: 'hidden', borderRadius: '8px', border: backgroundColor === url ? `2px solid ${primaryColor}` : '1px solid transparent' }}><img src={url} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>))}</div>
                                </div>
                             )}
                             {activeBgSource === "generate" && (<div style={{ display: 'flex', gap: '0.75rem' }}><input value={genKeyword} onChange={(e) => setGenKeyword(e.target.value)} placeholder="Keywords..." className="glass" style={{ flex: 1, padding: '0.8rem', borderRadius: '12px' }} /><button onClick={generateAbstract} className="btn btn-primary" style={{ padding: '0 1.5rem', borderRadius: '12px' }}>FORGE</button></div>)}
                         </div>
                      </section>
                   </div>

                   {/* LIVE PREVIEW AREA */}
                   <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                      <div className="glass" style={{ 
                        flex: 1, borderRadius: '32px', overflow: 'hidden', position: 'relative', border: `1px solid ${primaryColor}44`, background: previewBg, minHeight: '400px', boxShadow: `0 20px 80px -20px ${primaryColor}44`
                      }}>
                         <div style={{ position: 'absolute', inset: 0, backgroundImage: backgroundColor ? `url(${backgroundColor})` : 'none', backgroundSize: 'cover', backgroundPosition: 'center', filter: `blur(${backgroundBlur}px) brightness(${previewIsDark ? 0.6 : 1.1})`, transform: 'scale(1.1)' }} />
                         <div style={{ position: 'absolute', inset: 0, background: primaryColor, opacity: backgroundTint, mixBlendMode: previewIsDark ? 'soft-light' : 'overlay' }} />
                         <div style={{ position: 'relative', zIndex: 1, padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}><div style={{ width: '32px', height: '32px', borderRadius: '8px', background: primaryColor }} /><div style={{ fontSize: '1rem', fontWeight: 800, color: previewText }}>{dashboardTitle}</div></div>
                            <div className="glass" style={{ padding: '0.8rem 1rem', borderRadius: '12px', background: previewSectionBg, border: `1px solid ${primaryColor}15`, display: 'flex', alignItems: 'center', gap: '0.75rem' }}><Search size={14} style={{ opacity: 0.3 }} /><div style={{ height: '7px', width: '40%', background: previewText, opacity: 0.2, borderRadius: '4px' }} /></div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>{[1, 2].map(i => (<div key={i} className="glass" style={{ padding: '1rem', borderRadius: '16px', background: previewSectionBg, border: `1px solid ${primaryColor}15`, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}><div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><div style={{ width: '16px', height: '16px', borderRadius: '4px', background: primaryColor }} /><div style={{ height: '8px', width: '30%', background: previewText, opacity: 0.4, borderRadius: '4px' }} /></div><div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>{[1, 2].map(j => (<div key={j} className="glass" style={{ padding: '0.5rem', borderRadius: '8px', background: previewBookmarkBg, border: `1px solid ${primaryColor}11`, display: 'flex', alignItems: 'center', gap: '0.5rem' }}><div style={{ width: '12px', height: '12px', borderRadius: '4px', background: primaryColor }} /><div style={{ height: '6px', width: '50%', background: previewText, opacity: 0.3, borderRadius: '4px' }} /></div>))}</div></div>))}</div>
                         </div>
                      </div>
                      <div className="glass" style={{ display: 'flex', borderRadius: '14px', padding: '0.3rem', background: 'rgba(var(--primary-rgb), 0.05)', alignSelf: 'center' }}>
                         <button onClick={() => setPreviewIsDark(false)} style={{ padding: '0.5rem 1rem', borderRadius: '10px', background: !previewIsDark ? 'var(--primary)' : 'transparent', color: !previewIsDark ? '#fff' : 'var(--text)', border: 'none', cursor: 'pointer' }}><Sun size={18} /></button>
                         <button onClick={() => setPreviewIsDark(true)} style={{ padding: '0.5rem 1rem', borderRadius: '10px', background: previewIsDark ? 'var(--primary)' : 'transparent', color: previewIsDark ? '#fff' : 'var(--text)', border: 'none', cursor: 'pointer' }}><Moon size={18} /></button>
                      </div>
                   </div>
                </div>

                <div style={{ padding: '1.5rem 2.5rem', background: 'rgba(var(--primary-rgb), 0.04)', borderTop: '1px solid var(--glass-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    {editingTheme ? (
                       <button onClick={() => setIsDeleteModalOpen(true)} className="btn" style={{ color: '#ff4444', background: 'rgba(255,68,68,0.1)', padding: '0.8rem 1.5rem', borderRadius: '14px', display: 'flex', gap: '0.5rem', fontWeight: 700 }}>
                          <Trash2 size={18} /> Delete Theme
                       </button>
                    ) : <div />}
                    
                    <div style={{ display: 'flex', gap: '1.25rem' }}>
                       <button onClick={() => setIsModalOpen(false)} className="btn" style={{ padding: '0.8rem 2rem', borderRadius: '14px', fontWeight: 600, opacity: 0.6 }}>Cancel</button>
                       <button onClick={save} className="btn btn-primary" style={{ padding: '0.8rem 3rem', borderRadius: '14px', fontWeight: 800, fontSize: '1rem' }}>{editingTheme ? "Update Portfolio" : "Deploy Theme"}</button>
                    </div>
                </div>
             </div>
          </div>
       )}

       {/* DELETE CONFIRMATION MODAL */}
       {isDeleteModalOpen && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(20px)', zIndex: 1100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
             <div className="glass" style={{ width: '100%', maxWidth: '400px', padding: '2.5rem', borderRadius: '32px', textAlign: 'center', border: '1px solid rgba(255,68,68,0.2)' }}>
                <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(255,68,68,0.1)', color: '#ff4444', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto' }}><Trash2 size={32} /></div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>Archival Confirmation</h2>
                <p style={{ fontSize: '0.95rem', opacity: 0.6, marginBottom: '2.5rem' }}>This visual identity will be permanently decommissioned. Any workspaces relying on this theme will revert to system defaults.</p>
                <div style={{ display: 'flex', gap: '1.25rem' }}>
                   <button onClick={() => setIsDeleteModalOpen(false)} className="btn" style={{ flex: 1, padding: '0.8rem', borderRadius: '12px', fontWeight: 700 }}>Abort</button>
                   <button onClick={confirmDelete} className="btn" style={{ flex: 1, padding: '0.8rem', borderRadius: '12px', background: '#ff4444', color: '#fff', fontWeight: 800 }}>Confirm Deletion</button>
                </div>
             </div>
          </div>
       )}

       <style jsx global>{`
          .btn-sync:hover { transform: scale(1.15); background: var(--primary) !important; color: #fff !important; }
          .theme-thumbnail:hover { transform: scale(1.02); }
          .fade-in { animation: fadeIn 0.4s ease-out; }
          @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
       `}</style>
    </div>
  );
}
