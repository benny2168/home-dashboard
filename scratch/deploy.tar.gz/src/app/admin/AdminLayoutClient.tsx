"use client";

import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { redirect, usePathname } from "next/navigation";
import { useTheme } from "next-themes";
import { 
  Sun, 
  Moon, 
  LayoutGrid, 
  Home, 
  Layers, 
  Palette, 
  Users, 
  ArrowLeft,
  LogOut
} from "lucide-react";
import { IconComponent } from "@/components/IconPicker";
import * as actions from "@/app/admin/actions";

export default function AdminLayout({
   children,
   session,
   avatarColor
}: {
   children: React.ReactNode;
   session: any;
   avatarColor?: string | null;
}) {
  const pathname = usePathname();
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [globalSettings, setGlobalSettings] = useState<any>(null);

  useEffect(() => {
    setMounted(true);
    const fetchSettings = async () => {
      const settings = await actions.getGlobalSettings();
      setGlobalSettings(settings);
    };
    fetchSettings();
  }, []);

  useEffect(() => {
    if (globalSettings?.systemThemeColor) {
      document.documentElement.style.setProperty('--primary', globalSettings.systemThemeColor);
      const hex = globalSettings.systemThemeColor.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      document.documentElement.style.setProperty('--primary-rgb', `${r}, ${g}, ${b}`);
    }
  }, [globalSettings]);

  const userDepartment = session?.user?.department;
  const isAdmin = (session?.user as any)?.isAdmin;

  const initials = session?.user?.name
    ? session.user.name.trim().split(/\s+/).map((n: any) => n[0]).join('').toUpperCase().slice(0, 2)
    : (isAdmin ? "AD" : "U");

  const navItems = [
    { label: "Overview", href: "/admin", icon: Home },
    { label: "Workspace Tabs", href: "/admin/tabs", icon: Layers },
    { label: "Sections", href: "/admin/sections", icon: LayoutGrid },
    { label: "Themes", href: "/admin/theme", icon: Palette },
    { label: "User Management", href: "/admin/users", icon: Users },
  ];

  return (
    <div className="fade-in" style={{ minHeight: '100vh', padding: '2rem' }}>
      <header style={{ maxWidth: '1400px', margin: '0 auto 3rem auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
            {(globalSettings?.logoUrlLight || globalSettings?.logoUrlDark) && (
              <img 
                src={mounted && resolvedTheme === 'dark' 
                  ? (globalSettings.logoUrlDark || globalSettings.logoUrlLight || "")
                  : (globalSettings.logoUrlLight || globalSettings.logoUrlDark || "")
                }
                alt="System Logo"
                style={{ height: '32px', width: 'auto', objectFit: 'contain' }}
              />
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.1rem' }}>
                <h1 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text)', margin: 0, lineHeight: 1 }}>
                    Admin Portal
                </h1>
                <span style={{ fontSize: '0.7rem', opacity: 0.4, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    System Settings
                </span>
            </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div className="glass" style={{ padding: '0.4rem 1rem', borderRadius: '14px', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', paddingRight: '1rem', borderRight: '1px solid var(--glass-border)' }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: avatarColor || 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '0.8rem', fontWeight: 800, textShadow: '0 1px 2px rgba(0,0,0,0.2)' }}>
                {initials}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.1rem' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text)', fontFamily: 'inherit' }}>
                  {session?.user?.name || (isAdmin ? "Administrator" : "User")}
                </span>
                <span style={{ fontSize: '0.7rem', opacity: 0.5, fontWeight: 500, color: 'var(--text)', fontFamily: 'inherit' }}>
                  {userDepartment || "General"}
                </span>
              </div>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <button 
                onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")} 
                className="btn" 
                style={{ padding: '0.5rem', color: 'var(--text)', opacity: 0.6 }}
                title="Toggle Theme"
              >
                {mounted && resolvedTheme === "dark" ? (
                  <Sun size={18} />
                ) : (
                  <Moon size={18} />
                )}
              </button>

              <button 
                onClick={() => {
                  import("next-auth/react").then(mod => mod.signOut({ callbackUrl: "/" }));
                }} 
                className="btn" 
                style={{ padding: '0.5rem', color: '#f87171', opacity: 0.8 }}
                title="Sign Out"
              >
                <LogOut size={18} />
              </button>

              <a href="/" className="btn" style={{ padding: '0.5rem 1rem', borderRadius: '8px', fontSize: '0.85rem', fontWeight: 600, border: '1px solid var(--glass-border)', display: 'flex', gap: '0.5rem', color: 'var(--text)' }}>
                <ArrowLeft size={16} />
                Dashboard
              </a>
            </div>
          </div>
        </div>
      </header>

      <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'grid', gridTemplateColumns: '280px 1fr', gap: '3rem' }}>
        <aside style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <p style={{ fontSize: '0.75rem', fontWeight: 700, opacity: 0.4, textTransform: 'uppercase', letterSpacing: '0.05em', paddingLeft: '1rem', marginBottom: '0.5rem' }}>Management Hub</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <a 
                key={item.href}
                href={item.href} 
                className={`glass ${isActive ? 'active' : ''}`}
                style={{ 
                  padding: '1rem 1.25rem', 
                  borderRadius: '14px', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '1rem', 
                  color: 'var(--text)',
                  background: isActive ? 'rgba(var(--primary-rgb), 0.15)' : 'rgba(var(--primary-rgb), 0.05)',
                  border: isActive ? '1px solid var(--primary)' : '1px solid var(--glass-border)',
                  opacity: isActive ? 1 : 0.7,
                  transition: 'all 0.3s ease',
                  fontWeight: isActive ? 700 : 500
                }}
              >
                <Icon size={18} style={{ color: isActive ? 'var(--primary)' : 'inherit' }} />
                {item.label}
              </a>
            );
          })}
        </aside>

        <main>
          {children}
        </main>
      </div>

      <style jsx global>{`
        .fade-in { animation: fadeIn 0.4s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}
