import React, { Suspense } from "react";
import { prisma } from "@/lib/prisma";
import { LoginForm } from "./LoginForm";

export const dynamic = 'force-dynamic';

export default async function LoginPage() {
  const [globalSettings, activeTheme] = await Promise.all([
    (prisma as any).globalSettings.findUnique({ where: { id: "global" } }),
    prisma.theme.findFirst({ where: { isActive: true } })
  ]);

  const logoUrl = globalSettings?.logoUrlDark || globalSettings?.logoUrlLight || null;
  const themeColor = globalSettings?.systemThemeColor || activeTheme?.primaryColor || "#3b82f6";
  const logoIcon = activeTheme?.logoIcon || "LayoutGrid";

  return (
    <Suspense fallback={
      <div style={{ minHeight: '100vh', background: '#050505', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div className="animate-pulse" style={{ width: '40px', height: '40px', background: themeColor, borderRadius: '12px' }} />
      </div>
    }>
      <LoginForm 
        logoUrl={logoUrl} 
        themeColor={themeColor}
        logoIcon={logoIcon}
      />
    </Suspense>
  );
}
