"use client";

import React, { useState, useEffect } from "react";
import { signIn } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import { LogIn, ShieldCheck, LayoutGrid, Settings, Edit2, Check, LogOut } from "lucide-react";

const IconComponent = ({ name, size = 24, color = "currentColor" }: { name: string; size?: number, color?: string }) => {
  const icons: Record<string, any> = { LayoutGrid, ShieldCheck, Cpu: ShieldCheck, Settings, Edit2, Check, LogOut };
  const Icon = icons[name] || LayoutGrid;
  return <Icon size={size} color={color} />;
};

export function LoginForm({ logoUrl, themeColor, logoIcon }: { logoUrl?: string | null, themeColor: string, logoIcon?: string | null }) {
  const searchParams = useSearchParams();
  const error = searchParams.get("error");
  const errorDescription = searchParams.get("error_description");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  // Convert hex to rgb for glow effects
  const hexToRgb = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `${r}, ${g}, ${b}`;
  };

  const themeRgb = themeColor.startsWith('#') ? hexToRgb(themeColor) : "99, 102, 241";

  return (
    <div className="login-atmospheric-container" style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      position: 'relative',
      overflow: 'hidden',
      background: '#050505',
      fontFamily: "'Outfit', sans-serif"
    }}>
      {/* Ambient backgrounds */}
      <div style={{
        position: 'absolute',
        top: '-10%',
        right: '-10%',
        width: '60%',
        height: '60%',
        background: `radial-gradient(circle, rgba(${themeRgb}, 0.15) 0%, transparent 70%)`,
        filter: 'blur(100px)',
        zIndex: 0
      }} />
      <div style={{
        position: 'absolute',
        bottom: '-10%',
        left: '-10%',
        width: '50%',
        height: '50%',
        background: 'radial-gradient(circle, rgba(236, 72, 153, 0.1) 0%, transparent 70%)',
        filter: 'blur(100px)',
        zIndex: 0
      }} />

      <div className="glass fade-in" style={{ 
        width: '100%', 
        maxWidth: '450px', 
        padding: '3.5rem 3rem', 
        borderRadius: '32px', 
        zIndex: 1, 
        textAlign: 'center',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.6)',
        backdropFilter: 'blur(20px)',
        background: 'rgba(255,255,255,0.03)'
      }}>
        {logoUrl ? (
          <img 
            src={logoUrl} 
            alt="Logo" 
            style={{ height: '64px', width: 'auto', margin: '0 auto 2.5rem auto', filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.1))' }} 
          />
        ) : (
          <div style={{ 
            width: '80px', 
            height: '80px', 
            background: themeColor, 
            borderRadius: '24px', 
            margin: '0 auto 2.5rem auto', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            boxShadow: `0 0 40px rgba(${themeRgb}, 0.4)`
          }}>
            <IconComponent name={logoIcon || "LayoutGrid"} size={40} color="#fff" />
          </div>
        )}

        <h1 style={{ fontSize: '2.25rem', fontWeight: 800, marginBottom: '2.5rem', color: '#fff', letterSpacing: '-0.025em' }}>Dashboard</h1>

        {error && (
          <div className="glass" style={{ 
            padding: '1.25rem', 
            borderRadius: '16px', 
            background: 'rgba(239, 68, 68, 0.08)', 
            border: '1px solid rgba(239, 68, 68, 0.2)', 
            color: '#f87171', 
            fontSize: '0.9rem', 
            marginBottom: '2.5rem',
            textAlign: 'left',
            lineHeight: 1.5
          }}>
            <div style={{ fontWeight: 700, marginBottom: '0.25rem' }}>Authentication Error</div>
            {error === "AccessDenied" ? (
              <>
                <div style={{ opacity: 0.9 }}>You do not have permission to access this portal.</div>
                {errorDescription && <div style={{ marginTop: '0.5rem', opacity: 0.6, fontSize: '0.75rem' }}>{errorDescription}</div>}
              </>
            ) : "There was a problem signing you in. Please try again."}
          </div>
        )}

        <button 
          onClick={() => signIn("microsoft-entra-id", { callbackUrl: "/" })}
          className="btn"
          style={{ 
            width: '100%', 
            padding: '1.1rem', 
            borderRadius: '16px', 
            fontSize: '1rem', 
            fontWeight: 700, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            gap: '1.25rem',
            transition: 'all 0.3s ease',
            marginBottom: '2.5rem',
            background: '#fff',
            color: '#000',
            border: 'none',
            boxShadow: '0 4px 15px rgba(0,0,0,0.2)'
          }}
        >
          <svg width="22" height="22" viewBox="0 0 23 23">
            <path d="M11.5 0H0V11.5H11.5V0Z" fill="#f25022"/>
            <path d="M23 0H11.5V11.5H23V0Z" fill="#7fbb00"/>
            <path d="M11.5 11.5H0V23H11.5V11.5Z" fill="#00a1f1"/>
            <path d="M23 11.5H11.5V23H23V11.5Z" fill="#ffbb00"/>
          </svg>
          Sign in with Microsoft
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', marginBottom: '2.5rem', opacity: 0.1 }}>
          <div style={{ height: '1px', flex: 1, background: '#fff' }}></div>
          <span style={{ fontSize: '0.7rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.2em' }}>OR</span>
          <div style={{ height: '1px', flex: 1, background: '#fff' }}></div>
        </div>

        <form 
          onSubmit={async (e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const username = formData.get("username") as string;
            const password = formData.get("password") as string;
            await signIn("credentials", { username, password, callbackUrl: "/" });
          }}
          style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}
        >
          <div style={{ position: 'relative' }}>
             <input 
                name="username"
                type="text" 
                placeholder="Username" 
                style={{ 
                  width: '100%',
                  padding: '1.1rem 1.25rem', 
                  borderRadius: '16px', 
                  background: 'rgba(255,255,255,0.05)', 
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#fff',
                  fontSize: '0.95rem',
                  outline: 'none',
                  transition: 'all 0.3s ease'
                }}
              />
          </div>
          <div style={{ position: 'relative' }}>
              <input 
                name="password"
                type="password" 
                placeholder="Password" 
                style={{ 
                  width: '100%',
                  padding: '1.1rem 1.25rem', 
                  borderRadius: '16px', 
                  background: 'rgba(255,255,255,0.05)', 
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#fff',
                  fontSize: '0.95rem',
                  outline: 'none',
                  transition: 'all 0.3s ease'
                }}
              />
          </div>
          <button 
            type="submit"
            style={{ 
              padding: '1.1rem', 
              borderRadius: '16px', 
              background: 'rgba(255,255,255,0.1)', 
              color: '#fff',
              fontWeight: 700,
              fontSize: '1rem',
              border: '1px solid rgba(255,255,255,0.1)',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
          >
            Authenticate Locally
          </button>
        </form>

        <div style={{ marginTop: '3.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', opacity: 0.25 }}>
           <ShieldCheck size={14} />
           <span style={{ fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.15em' }}>Secure Identity Manifest</span>
        </div>
      </div>

      <style jsx global>{`
        .fade-in {
          animation: fadeIn 1s cubic-bezier(0.4, 0, 0.2, 1);
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        input:focus {
          border-color: ${themeColor} !important;
          background: rgba(255,255,255,0.08) !important;
          box-shadow: 0 0 20px rgba(${themeRgb}, 0.15);
        }
        button:hover {
          filter: brightness(1.1);
          transform: translateY(-2px);
        }
        input::placeholder {
          color: rgba(255,255,255,0.3);
        }
      `}</style>
    </div>
  );
}
