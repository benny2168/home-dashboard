"use client";

import React, { useState, useMemo, useEffect, useRef } from "react";
import * as LucideIcons from "lucide-react";
import { 
  Search, 
  Settings, 
  Edit2, 
  Trash2, 
  ExternalLink, 
  Moon, 
  Sun, 
  LayoutGrid, 
  ChevronDown, 
  ChevronRight, 
  MoreVertical, 
  GripVertical,
  LogOut,
  Maximize2,
  Plus,
  Move,
  X,
  Upload,
  LayoutTemplate,
  Copy,
  ChevronLeft,
  Grid,
  ArrowRight,
  PlusCircle,
  Layout,
  Download,
  Library,
  Check
} from "lucide-react";
import { useTheme } from "next-themes";
import * as actions from "@/app/admin/actions";
import { useSearchParams, useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { signOut } from "next-auth/react";
import { IconComponent, IconPicker } from "./IconPicker";

interface Bookmark {
  id: string;
  title: string;
  url: string;
  description?: string | null;
  icon?: string | null;
  openInNewTab: boolean;
  order: number;
}

interface Section {
  id: string;
  title: string;
  icon?: string | null;
  height?: number | null;
  isAutoResize?: boolean;
  column: number;
  bookmarks: Bookmark[];
  editors: { id: string }[];
}

interface Theme {
  id: string;
  name: string;
  primaryColor: string;
  backgroundColor: string | null;
  dashboardTitle: string | null;
  darkMode: boolean;
  glassEffect: boolean;
  backgroundBlur?: number | null;
  backgroundTint?: number | null;
  sectionOpacity?: number | null;
  glassOpacity?: number | null;
  logoUrlLight?: string | null;
  logoUrlDark?: string | null;
}

interface Tab {
  id: string;
  title: string;
  icon?: string | null;
  organization: string | null;
  columns: number;
  sections: Section[];
  theme?: Theme | null;
  themeId?: string | null;
  owners: { id: string }[];
  editors: { id: string }[];
  allowedUsers: { id: string }[];
}

const AmbientBackground = ({ theme }: { theme?: Theme | null }) => {
  if (!theme) return null;
  
  const bgImg = (theme.backgroundColor && (theme.backgroundColor.startsWith('http') || theme.backgroundColor.startsWith('/') || theme.backgroundColor.startsWith('api') || theme.backgroundColor.startsWith('data:'))) ? theme.backgroundColor : null;
  
  return (
    <div 
      className="ambient-background-layer"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: -1,
        overflow: 'hidden',
        background: 'var(--bg-base)',
        pointerEvents: 'none'
      }}
    >
      {/* Dynamic Mesh Gradients (Theme Tint) - High Intensity */}
      <div 
        style={{
          position: 'absolute',
          top: '-20%',
          right: '-10%',
          width: '80%',
          height: '80%',
          background: 'radial-gradient(circle, var(--primary-glow) 0%, transparent 60%)',
          filter: 'blur(100px)',
          opacity: 0.8,
          animation: 'float 20s infinite alternate linear'
        }}
      />
      <div 
        style={{
          position: 'absolute',
          bottom: '-20%',
          left: '-10%',
          width: '70%',
          height: '70%',
          background: 'radial-gradient(circle, var(--primary-glow) 0%, transparent 60%)',
          filter: 'blur(120px)',
          opacity: 0.6,
          animation: 'float 25s infinite alternate-reverse linear'
        }}
      />

      {/* Image Layer (if exists) */}
      {bgImg && (
        <div 
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `url(${bgImg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: `blur(${theme.backgroundBlur ?? 20}px) brightness(0.7)`,
            transform: 'scale(1.1)',
            opacity: 0.8
          }}
        />
      )}

      {/* Dynamic Tint Overlay (Always active for atmospheric depth) */}
      <div 
        style={{
          position: 'absolute',
          inset: 0,
          background: 'var(--primary)',
          opacity: bgImg ? (theme.backgroundTint ?? 0.6) : 0.08,
          mixBlendMode: theme.darkMode ? 'soft-light' : 'overlay'
        }}
      />

      {/* Atmospheric Grain/Noise */}
      <div 
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0.03,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          pointerEvents: 'none'
        }}
      />

      <style jsx>{`
        @keyframes float {
          0% { transform: translate(0, 0) scale(1); }
          100% { transform: translate(50px, 30px) scale(1.1); }
        }
      `}</style>
    </div>
  );
};
interface DashboardProps {
  tabs: Tab[];
  activeTheme: Theme;
  globalSettings: {
    logoUrlLight?: string | null;
    logoUrlDark?: string | null;
    systemThemeColor: string;
  };
  userDepartment?: string | null;
  isAdmin: boolean;
  currentUserId: string;
  canEditContent: boolean;
  iconSize?: number;
  libraryTabs: Tab[];
  librarySections: Section[];
  userName?: string | null;
  avatarColor?: string | null;
}

// --- UTILITIES & COMPONENTS ---

const getContrastYIQ = (hexcolor: string) => {
  if (!hexcolor || hexcolor.startsWith('var')) return 'white';
  const hex = hexcolor.replace("#", "");
  if (hex.length < 6) return 'white';
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
  return (yiq >= 128) ? '#1a1a1a' : 'white';
};

// --- MAIN DASHBOARD COMPONENT ---

export function Dashboard({ 
  tabs: initialTabs, 
  activeTheme, 
  globalSettings,
  userDepartment, 
  isAdmin, 
  currentUserId,
  canEditContent,
  iconSize = 36,
  libraryTabs,
  librarySections,
  userName,
  avatarColor
}: DashboardProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [tabs, setTabs] = useState(initialTabs);
  const [activeTabId, setActiveTabId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [isEditMode, setIsEditMode] = useState(false);
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"add" | "edit">("add");
  const [editingBookmark, setEditingBookmark] = useState<Bookmark | null>(null);
  const [targetSectionId, setTargetSectionId] = useState<string>("");
  const [iconRegistry, setIconRegistry] = useState<string[]>([]);
  const [iconSearchQuery, setIconSearchQuery] = useState("");
  const [liveIconPreview, setLiveIconPreview] = useState<string | null | undefined>(null);

  // Tab & Section Modals
  const [isTabModalOpen, setIsTabModalOpen] = useState(false);
  const [editingTabForModal, setEditingTabForModal] = useState<Tab | null>(null);
  
  const [isSectionModalOpen, setIsSectionModalOpen] = useState(false);
  const [editingSectionForModal, setEditingSectionForModal] = useState<Section | null>(null);
  const [targetColumnForNewSection, setTargetColumnForNewSection] = useState<number>(0);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [catalogSearchQuery, setCatalogSearchQuery] = useState("");
  const [importingSectionId, setImportingSectionId] = useState<string | null>(null);
  const [justImportedId, setJustImportedId] = useState<string | null>(null);

  // Drag state
  const dragItemId = useRef<string | null>(null);
  const dragType = useRef<"bookmark" | "section" | "tab" | null>(null);
  const dragSourceId = useRef<string | null>(null); 
  const [dragOverTabId, setDragOverTabId] = useState<string | null>(null);
  const [dragOverSectionId, setDragOverSectionId] = useState<string | null>(null);
  const [dragOverBookmarkId, setDragOverBookmarkId] = useState<string | null>(null);
  const [dragOverSide, setDragOverSide] = useState<"top" | "bottom" | null>(null);
  const [dragOverColIdx, setDragOverColIdx] = useState<number | null>(null);
  const [resizingId, setResizingId] = useState<string | null>(null);
  const resizeStartY = useRef<number>(0);
  const resizeStartHeight = useRef<number>(0);
  const bookmarkUrlRef = useRef<HTMLInputElement>(null);

  const activeTab = tabs.find(t => t.id === activeTabId);
  const isOwner = isAdmin || activeTab?.owners?.some((o: any) => o.id === currentUserId);
  const isEditor = isOwner || activeTab?.editors?.some((e: any) => e.id === currentUserId);
  
  // Section-specific editors on this tab
  const isSectionEditor = activeTab?.sections?.some((s: any) => 
    s.editors?.some((e: any) => e.id === currentUserId)
  );

  const canEdit = isEditor || isSectionEditor || canEditContent;
  const showEditControls = canEdit && isEditMode;

  const initials = userName 
    ? userName.trim().split(/\s+/).map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : (isAdmin ? "AD" : "U");

  // --- PERSISTENCE & INITIALIZATION ---
  useEffect(() => {
    const urlTabId = searchParams.get('tabId');
    const urlTabName = searchParams.get('tab');
    const lastTabId = localStorage.getItem('last-tab-id');

    let targetTabId = initialTabs[0]?.id || '';
    
    if (urlTabId) targetTabId = urlTabId;
    else if (urlTabName) {
        const matched = initialTabs.find(t => t.title.toLowerCase() === urlTabName.toLowerCase());
        if (matched) targetTabId = matched.id;
    } else if (lastTabId && initialTabs.some(t => t.id === lastTabId)) {
        targetTabId = lastTabId;
    }
    
    setActiveTabId(targetTabId);
    
    // Restore edit mode from URL signal
    const editMode = searchParams.get('edit') === 'true';
    if (editMode && (isAdmin || canEditContent)) {
      setIsEditMode(true);
    }
    
    setMounted(true);
  }, [initialTabs, searchParams, isAdmin, canEditContent]);

  // --- HELPERS ---
  const handleResizeStart = (e: React.MouseEvent, sectionId: string, currentHeight: number) => {
    e.preventDefault();
    setResizingId(sectionId);
    resizeStartY.current = e.clientY;
    resizeStartHeight.current = currentHeight || 120;
    
    const handleMouseMove = (em: MouseEvent) => {
        const delta = em.clientY - resizeStartY.current;
        const newHeight = Math.max(80, resizeStartHeight.current + delta);
        setTabs(prev => prev.map(tab => tab.id === activeTabId ? {
            ...tab,
            sections: tab.sections.map(s => s.id === sectionId ? { ...s, height: newHeight } : s)
        } : tab));
    };
    
    const handleMouseUp = async (eu: MouseEvent) => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        
        // Find the height from the state we just updated
        const currentTabs = await new Promise<Tab[]>(resolve => setTabs(t => { resolve(t); return t; }));
        const section = currentTabs.find(t => t.id === activeTabId)?.sections.find(s => s.id === sectionId);
        
        if (section) {
            const h = (section.height !== undefined && section.height !== null) ? Math.round(section.height) : null;
            await actions.updateSectionLayout(sectionId, activeTabId, { height: h });
        }
        setResizingId(null);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleTabSwitch = (id: string, title?: string) => {
    setActiveTabId(id);
    localStorage.setItem('last-tab-id', id);
    const params = new URLSearchParams(searchParams.toString());
    params.set('tab', title || tabs.find(t => t.id === id)?.title || '');
    params.delete('tabId');
    router.replace(`${pathname}?${params.toString()}`, { scroll: false });
  };

  // Helper for Upload
  const handlePickerUpload = async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    const url = await actions.uploadImage(formData);
    if (url) setLiveIconPreview(url);
  };

  const handleFetchFavicon = async () => {
    const url = bookmarkUrlRef.current?.value;
    if (!url) return;
    const favicon = await actions.fetchFavicon(url);
    if (favicon) setLiveIconPreview(favicon);
  };

  // Sync CSS Variables (Primary color from Tab/Theme)
  const isDark = resolvedTheme === "dark";
  useEffect(() => {
    const root = document.documentElement;
    const themeToUse = activeTab?.theme || activeTheme;
    if (!themeToUse) return;
    
    root.style.setProperty('--primary', themeToUse.primaryColor);
    
    // Extract RGB for alpha-based gradients
    const hex = themeToUse.primaryColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    root.style.setProperty('--primary-rgb', `${r}, ${g}, ${b}`);
    
    root.style.setProperty('--primary-glow', `rgba(${r}, ${g}, ${b}, 0.3)`);
    root.style.setProperty('--nav-text', getContrastYIQ(themeToUse.primaryColor));
    
    if (isDark) {
      root.style.setProperty('--text', '#ffffff');
      root.style.setProperty('--text-dim', 'rgba(255,255,255,0.5)');
      root.style.setProperty('--bg-base', '#0a0a0a');
    } else {
      root.style.setProperty('--text', '#0f172a');
      root.style.setProperty('--text-dim', 'rgba(15,23,42,0.5)');
      root.style.setProperty('--bg-base', '#f8fafc');
    }

    // Dynamic Opacity Layers
    const sOp = themeToUse.sectionOpacity ?? (isDark ? 0.7 : 0.65);
    const gOp = themeToUse.glassOpacity ?? (isDark ? 0.12 : 0.1);
    root.style.setProperty('--section-opacity', sOp.toString());
    root.style.setProperty('--glass-opacity', gOp.toString());
    
    // Update the glass background token dynamically
    if (isDark) {
      root.style.setProperty('--glass-bg', `rgba(${r}, ${g}, ${b}, ${gOp})`);
    } else {
      root.style.setProperty('--glass-bg', `rgba(255, 255, 255, ${sOp})`);
    }

  }, [activeTab, activeTheme, isDark]);

  // Fetch icons
  useEffect(() => {
    const fetchIcons = async () => {
      try {
        const [dashRes, selfRes] = await Promise.all([
          fetch("https://raw.githubusercontent.com/homarr-labs/dashboard-icons/main/tree.json"),
          fetch("https://cdn.jsdelivr.net/gh/selfhst/icons/index.json")
        ]);
        
        const dashData = await dashRes.json();
        const selfData = await selfRes.json();
        
        let allIcons: string[] = [];
        
        // DashboardIcons processing
        if (Array.isArray(dashData)) {
            allIcons = dashData.map((item: any) => typeof item === 'string' ? item : item.name);
        } else if (dashData && typeof dashData === 'object') {
            const list = dashData.png || dashData.icons || [];
            if (Array.isArray(list)) allIcons = list.map((n: string) => n.replace('.png', ''));
        }
        
        // selfh.st processing
        if (Array.isArray(selfData)) {
            const selfIcons = selfData.map((item: any) => `https://cdn.jsdelivr.net/gh/selfhst/icons/png/${item.id}.png`);
            allIcons = [...allIcons, ...selfIcons];
        }

        if (allIcons.length > 0) setIconRegistry(allIcons);
      } catch (err) {}
    };
    fetchIcons();
  }, []);

  // --- DRAG & DROP HANDLERS ---
  
  const handleDragStart = (e: React.DragEvent, id: string, type: "bookmark" | "section" | "tab", sourceId?: string) => {
    if (!showEditControls) return;
    dragItemId.current = id;
    dragType.current = type;
    dragSourceId.current = sourceId || null;
    e.stopPropagation();
  };

  const handleDragOver = (e: React.DragEvent, id?: string, type?: "tab" | "column" | "section" | "bookmark", colIdx?: number) => {
    if (!showEditControls) return;
    e.preventDefault();
    if (type === "tab") setDragOverTabId(id || null);
    if (type === "column") setDragOverColIdx(id ? parseInt(id) : null);
    
    if (type === "section" || type === "bookmark") {
        const rect = e.currentTarget.getBoundingClientRect();
        const mid = rect.top + rect.height / 2;
        const side = e.clientY < mid ? "top" : "bottom";
        setDragOverSide(side);
        
        if (type === "section") {
            setDragOverSectionId(id || null);
            if (colIdx !== undefined) setDragOverColIdx(colIdx);
        } else {
            setDragOverBookmarkId(id || null);
        }
    }
  };

  const handleDrop = async (targetId: string, type: "column" | "section" | "tab" | "bookmark") => {
    if (!showEditControls || !dragItemId.current) return;
    
    const id = dragItemId.current;
    const sourceType = dragType.current;
    const side = dragOverSide;

    setDragOverTabId(null);
    setDragOverColIdx(null);
    setDragOverSectionId(null);
    setDragOverBookmarkId(null);
    setDragOverSide(null);

    // --- TAB DRAG & DROP ---
    if (sourceType === "tab" && type === "tab") {
        const sourceIdx = tabs.findIndex(t => t.id === id);
        const targetIdx = tabs.findIndex(t => t.id === targetId);
        if (sourceIdx !== -1 && targetIdx !== -1 && sourceIdx !== targetIdx) {
            const newTabs = [...tabs];
            const [removed] = newTabs.splice(sourceIdx, 1);
            newTabs.splice(targetIdx, 0, removed);
            setTabs(newTabs);
            await actions.reorderTabs(newTabs.map(t => t.id));
        }
    }

    // --- SECTION DRAG & DROP ---
    if (sourceType === "section" && (type === "column" || type === "section")) {
        const targetCol = type === "column" ? parseInt(targetId) : (activeTab?.sections.find(s => s.id === targetId)?.column ?? 0);
        let beforeSectionId = undefined;
        if (type === "section") {
            if (side === "top") beforeSectionId = targetId;
            else {
                const colSections = dashboardColumns[targetCol];
                const targetIdx = colSections.findIndex(s => s.id === targetId);
                if (targetIdx !== -1 && targetIdx < colSections.length - 1) beforeSectionId = colSections[targetIdx + 1].id;
            }
        }
        
        setTabs(prev => prev.map(t => t.id === activeTabId ? {
            ...t,
            sections: (() => {
                const currentSec = t.sections.find(s => s.id === id)!;
                const filtered = t.sections.filter(s => s.id !== id);
                const updatedSec = { ...currentSec, column: targetCol };
                if (!beforeSectionId) return [...filtered, updatedSec];
                const insertIdx = filtered.findIndex(s => s.id === beforeSectionId);
                const result = [...filtered];
                result.splice(insertIdx, 0, updatedSec);
                return result;
            })()
        } : t));

        await actions.moveSection(id, activeTabId, targetCol, beforeSectionId);
    }

    // --- BOOKMARK DRAG & DROP ---
    if (sourceType === "bookmark" && (type === "section" || type === "bookmark")) {
        let destSectionId = targetId;
        let beforeBookmarkId = undefined;
        const sec = activeTab?.sections.find(s => s.bookmarks.some(b => b.id === targetId));
        if (type === "bookmark") {
            destSectionId = sec?.id || targetId;
            if (side === "top") beforeBookmarkId = targetId;
            else {
                const bms = sec?.bookmarks || [];
                const idx = bms.findIndex(b => b.id === targetId);
                if (idx !== -1 && idx < bms.length - 1) beforeBookmarkId = bms[idx + 1].id;
            }
        }

        setTabs(prev => prev.map(tab => tab.id === activeTabId ? {
            ...tab,
            sections: tab.sections.map(s => {
                const isSource = s.bookmarks.some(b => b.id === id);
                const isDest = s.id === destSectionId;
                if (!isSource && !isDest) return s;
                
                const bookmarkToMove = tab.sections.flatMap(sec => sec.bookmarks).find(b => b.id === id)!;
                let newBookmarks = s.bookmarks.filter(b => b.id !== id);
                
                if (isDest) {
                    if (!beforeBookmarkId) newBookmarks.push(bookmarkToMove);
                    else {
                        const insertIdx = newBookmarks.findIndex(b => b.id === beforeBookmarkId);
                        newBookmarks.splice(insertIdx, 0, bookmarkToMove);
                    }
                }
                return { ...s, bookmarks: newBookmarks };
            })
        } : tab));

        await actions.moveBookmark(id, destSectionId, beforeBookmarkId);
    }

    dragItemId.current = null;
    dragType.current = null;
    dragSourceId.current = null;
  };

  const toggleSection = (id: string) => {
    setCollapsedSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const dashboardColumns = useMemo(() => {
    const colCount = activeTab?.columns || 4;
    const cols: Section[][] = Array.from({ length: colCount }, () => []);
    if (!activeTab) return cols;
    const sections = activeTab.sections
      .map((section) => ({
        ...section,
        bookmarks: section.bookmarks.filter((b) =>
          b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          b.description?.toLowerCase().includes(searchQuery.toLowerCase())
        ),
      }))
      .filter((section) => section.bookmarks.length > 0 || !searchQuery || showEditControls);
    sections.forEach((sec) => {
      const colIdx = Math.min(Math.max(sec.column, 0), colCount - 1);
      cols[colIdx].push(sec);
    });
    return cols;
  }, [activeTab, searchQuery, showEditControls]);

  const openAddModal = (sectionId: string) => {
    setModalMode("add");
    setTargetSectionId(sectionId);
    setEditingBookmark(null);
    setLiveIconPreview(null);
    setIsModalOpen(true);
  };

  const openEditModal = (bookmark: Bookmark, sectionId: string) => {
    setModalMode("edit");
    setTargetSectionId(sectionId);
    setEditingBookmark(bookmark);
    setLiveIconPreview(bookmark.icon);
    setIsModalOpen(true);
  };

  const colCount = activeTab?.columns || 4;
  const containerMaxWidth = Math.min(2400, Math.max(1400, colCount * 400));

  return (
    <>
      <AmbientBackground theme={activeTab?.theme || activeTheme} />
      <div 
        style={{ 
          position: 'fixed', 
          top: '20px',
          bottom: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          width: 'calc(100% - 40px)',
          maxWidth: `${containerMaxWidth}px`,
          borderRadius: '24px', 
          zIndex: 0, 
          pointerEvents: 'none',
          boxShadow: '0 20px 50px rgba(0,0,0,0.1)',
          transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
          background: resolvedTheme === 'light' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(var(--primary-rgb), 0.03)',
          backdropFilter: 'blur(12px)',
          border: '1px solid var(--glass-border)'
        }} 
      />
      <div className="dashboard-container" style={{ minHeight: '100vh', padding: '2rem', position: 'relative', zIndex: 1 }}>
         <header style={{ maxWidth: `${containerMaxWidth - 60}px`, margin: '0 auto 3rem auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'all 0.5s ease' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
            {(globalSettings.logoUrlLight || globalSettings.logoUrlDark) && (
              <img 
                src={mounted && resolvedTheme === 'dark' 
                  ? (globalSettings.logoUrlDark || globalSettings.logoUrlLight || "")
                  : (globalSettings.logoUrlLight || globalSettings.logoUrlDark || "")
                }
                alt="System Logo"
                style={{ height: '60px', width: 'auto', objectFit: 'contain', transition: 'all 0.4s ease' }}
              />
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.1rem' }}>
                <h1 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text)', margin: 0, lineHeight: 1 }}>
                    {(activeTab?.theme || activeTheme)?.dashboardTitle || "Dashboard"}
                </h1>
                <span style={{ fontSize: '0.7rem', opacity: 0.4, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {activeTab?.title}
                </span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
             <div className="glass glass-card" style={{ padding: '0.6rem 1.25rem', borderRadius: '16px', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', paddingRight: '1.25rem', borderRight: '1px solid var(--glass-border)' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: avatarColor || 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '0.8rem', fontWeight: 800, textShadow: '0 1px 2px rgba(0,0,0,0.2)' }}>
                       {initials}
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.1rem' }}>
                       <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text)', fontFamily: 'inherit' }}>{userName || (isAdmin ? "Administrator" : "User")}</span>
                       <span style={{ fontSize: '0.7rem', opacity: 0.5, fontWeight: 500, color: 'var(--text)', fontFamily: 'inherit' }}>{userDepartment || "General"}</span>
                    </div>
                </div>
                
                <button 
                  onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")} 
                  className="btn" 
                  style={{ padding: '0.5rem', color: 'var(--text)', opacity: 0.6 }}
                >
                   {mounted && resolvedTheme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
                </button>

                {isAdmin && (
                  <Link href="/admin" className="btn" style={{ padding: '0.5rem', color: 'var(--text)', opacity: 0.8 }} title="Admin Portal">
                     <Settings size={18} />
                  </Link>
                )}

                <button 
                  onClick={() => signOut({ callbackUrl: "/" })} 
                  className="btn" 
                  style={{ padding: '0.5rem', color: '#f87171', opacity: 0.8 }}
                  title="Sign Out"
                >
                   <LogOut size={18} />
                </button>

                {canEdit && (
                  <button 
                    onClick={() => {
                      const newVal = !isEditMode;
                      setIsEditMode(newVal);
                      const params = new URLSearchParams(searchParams.toString());
                      if (newVal) params.set('edit', 'true');
                      else params.delete('edit');
                      router.replace(`${pathname}?${params.toString()}`, { scroll: false });
                    }} 
                    className={`btn ${isEditMode ? 'btn-primary' : ''}`} 
                    style={{ padding: '0.5rem 1rem', borderRadius: '8px', fontSize: '0.85rem', fontWeight: 600, display: 'flex', gap: '0.5rem' }}
                  >
                     {isEditMode ? <Settings size={16} /> : <Edit2 size={16} />}
                     {isEditMode ? "Done Editing" : "Edit Mode"}
                  </button>
                 )}

              </div>
           </div>
        </header>

        <main style={{ maxWidth: `${containerMaxWidth - 60}px`, margin: '0 auto', transition: 'all 0.5s ease' }}>
           <div className="tabs-container" style={{ marginBottom: '2rem' }}>
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
              <div className="glass" style={{ flex: 1, position: 'relative', border: resolvedTheme === 'light' ? '1px solid rgba(var(--primary-rgb), 0.3)' : '1px solid var(--glass-border)' }}>
                <Search size={20} style={{ position: 'absolute', left: '1.25rem', top: '50%', transform: 'translateY(-50%)', opacity: resolvedTheme === 'light' ? 0.8 : 0.6 }} />
                <input 
                  type="text" 
                  placeholder="Find tools or apps..." 
                  className="glass search-input" 
                  style={{ 
                    width: '100%', 
                    padding: '1rem 1rem 1rem 3.5rem', 
                    borderRadius: '16px', 
                    fontSize: '1rem',
                    background: 'var(--glass-bg)'
                  }}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              {showEditControls && (
                <button 
                  onClick={() => setIsLibraryOpen(true)}
                  className="btn btn-primary"
                  style={{ 
                    padding: '0 1.5rem', borderRadius: '16px', fontSize: '0.9rem', fontWeight: 700, 
                    display: 'flex', alignItems: 'center', gap: '0.6rem',
                    whiteSpace: 'nowrap',
                    boxShadow: '0 8px 20px rgba(var(--primary-rgb), 0.3)'
                  }}
                >
                    <Library size={18} />
                    Explore Section Catalog
                </button>
              )}
            </div>

            <div style={{ display: 'flex', gap: '0.5rem', borderBottom: '1px solid var(--glass-border)', alignItems: 'center' }}>
              {tabs.map((tab) => (
                <div 
                    key={tab.id} 
                    style={{ 
                        position: 'relative', 
                        display: 'flex', 
                        alignItems: 'center',
                        borderLeft: dragOverTabId === tab.id && dragType.current === "tab" ? "3px solid var(--primary)" : "none",
                        paddingLeft: dragOverTabId === tab.id && dragType.current === "tab" ? "4px" : "0",
                        transition: 'all 0.1s'
                    }}
                    draggable={showEditControls}
                    onDragStart={(e) => handleDragStart(e, tab.id, "tab")}
                    onDragOver={(e) => handleDragOver(e, tab.id, "tab")}
                    onDragLeave={() => setDragOverTabId(null)}
                    onDrop={() => handleDrop(tab.id, "tab")}
                >
                  <button
                    onClick={() => handleTabSwitch(tab.id, tab.title)}
                    className={`btn tab-pill ${activeTabId === tab.id ? 'active' : ''}`}
                    style={{
                      background: activeTabId === tab.id ? 'var(--primary)' : 'rgba(var(--primary-rgb), 0.05)',
                      color: activeTabId === tab.id ? 'var(--nav-text)' : 'var(--text)',
                      borderRadius: '14px 14px 0 0', 
                      padding: '0.85rem 2.25rem',
                      fontWeight: activeTabId === tab.id ? 700 : 600,
                      display: 'flex', alignItems: 'center', gap: '0.75rem',
                      cursor: showEditControls ? 'grab' : 'pointer',
                      border: '1px solid var(--glass-border)',
                      borderBottom: activeTabId === tab.id ? '1px solid var(--primary)' : '1px solid var(--glass-border)',
                      marginBottom: '-1px',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      position: 'relative',
                      zIndex: activeTabId === tab.id ? 2 : 1,
                      transform: activeTabId === tab.id ? 'translateY(1px)' : 'none',
                      boxShadow: activeTabId === tab.id ? '0 -4px 12px rgba(var(--primary-rgb), 0.15)' : 'none',
                      letterSpacing: '0.02em'
                    }}
                  >
                    <IconComponent name={tab.icon || "LayoutTemplate"} size={18} />
                    {tab.title}
                  </button>
                </div>
              ))}
              {showEditControls && (
                <button onClick={() => { setEditingTabForModal(null); setLiveIconPreview(null); setIsTabModalOpen(true); }} className="btn" style={{ padding: '0.5rem', borderRadius: '50%', background: 'rgba(255,255,255,0.1)' }}>
                   <Plus size={18} />
                </button>
              )}
            </div>
          </div>

          <div className="dashboard-grid-wrapper" style={{ overflowX: 'auto', paddingBottom: '2rem', paddingRight: '1rem', marginLeft: '-1rem', paddingLeft: '1rem' }}>
            <div className="dashboard-grid" style={{ 
               display: 'grid', 
               gridTemplateColumns: `repeat(${colCount}, minmax(300px, 1fr))`, 
               gap: '1.5rem',
               width: 'max-content',
               minWidth: '100%',
               maxWidth: `${containerMaxWidth - 60}px`,
               margin: '0 auto',
               transition: 'all 0.5s ease'
            }}>
              {dashboardColumns.map((col, colIdx) => (
                <div 
                  key={colIdx} 
                style={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  gap: '1.5rem', 
                  minHeight: '100px',
                  borderRadius: '16px',
                  background: dragOverColIdx === colIdx && dragType.current === "section" ? 'rgba(var(--primary-rgb), 0.08)' : 'transparent',
                  transition: 'all 0.4s ease'
                }}
                onDragOver={(e) => handleDragOver(e, colIdx.toString(), "column")}
                onDragLeave={() => { setDragOverColIdx(null); setDragOverSectionId(null); }}
                onDrop={() => handleDrop(colIdx.toString(), "column")}
              >
                {dashboardColumns[colIdx].map((section) => (
                  <div 
                    key={section.id} 
                    className="glass glass-card"
                    style={{
                        background: dragOverSectionId === section.id && dragType.current === "section" ? 'rgba(var(--primary-rgb), 0.15)' : 'var(--glass-bg)',
                        borderColor: dragOverSectionId === section.id && dragType.current === "section" ? 'var(--primary)' : 'var(--glass-border)',
                        transition: 'all 0.2s ease',
                        borderTop: dragOverSectionId === section.id && dragType.current === "section" && dragOverSide === "top" ? '4px solid var(--primary)' : '1px solid var(--glass-border)',
                        borderBottom: dragOverSectionId === section.id && dragType.current === "section" && dragOverSide === "bottom" ? '4px solid var(--primary)' : 'none',
                    }}
                    draggable={showEditControls}
                    onDragStart={(e) => handleDragStart(e, section.id, "section")}
                    onDragOver={(e) => handleDragOver(e, section.id, "section", colIdx)}
                    onDragLeave={() => setDragOverSectionId(null)}
                    onDrop={(e) => { e.stopPropagation(); handleDrop(section.id, "section"); }}
                  >
                    <div 
                      onDragOver={(e) => handleDragOver(e, section.id, "section", colIdx)}
                      onDrop={(e) => { e.stopPropagation(); handleDrop(section.id, "section"); }}
                      style={{ padding: '1rem', borderBottom: '1px solid var(--glass-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                    >
                        <div onClick={() => !showEditControls && toggleSection(section.id)} style={{ cursor: showEditControls ? 'grab' : 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
                          {showEditControls ? <Move size={16} /> : (collapsedSections[section.id] ? <ChevronRight size={16} /> : <ChevronDown size={16} />)}
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <IconComponent name={section.icon || "LayoutGrid"} size={18} />
                            <h2 style={{ fontSize: '1rem', margin: 0, fontWeight: 600 }}>{section.title}</h2>
                          </div>
                        </div>
                        {showEditControls && (
                          <div style={{ display: 'flex', gap: '0.4rem' }}>
                             <button onClick={() => { setEditingSectionForModal(section); setLiveIconPreview(section.icon ?? null); setIsSectionModalOpen(true); }} className="btn" style={{ padding: '6px' }}><Edit2 size={14} /></button>
                            <button onClick={() => openAddModal(section.id)} className="btn" style={{ padding: '6px' }}><Plus size={16} /></button>
                          </div>
                        )}
                      </div>
                      {!collapsedSections[section.id] && (
                        <div 
                            onDragOver={handleDragOver}
                            onDrop={(e) => { e.stopPropagation(); handleDrop(section.id, "section"); }}
                            style={{ 
                                padding: '0.75rem', 
                                display: 'flex', 
                                flexDirection: 'column', 
                                gap: '0.5rem', 
                                minHeight: '40px',
                                height: section.height ? `${section.height}px` : 'auto',
                                overflowY: section.height ? 'auto' : 'visible'
                            }}
                        >
                          {section.bookmarks.map((bookmark) => (
                            <a 
                                key={bookmark.id} 
                                href={showEditControls ? "#" : bookmark.url} 
                                target={!showEditControls && bookmark.openInNewTab ? "_blank" : "_self"}
                                rel={bookmark.openInNewTab ? "noopener noreferrer" : undefined}
                                draggable={showEditControls}
                                onDragStart={(e) => handleDragStart(e, bookmark.id, "bookmark", section.id)}
                                onDragOver={(e) => handleDragOver(e, bookmark.id, "bookmark")}
                                onDragLeave={() => setDragOverBookmarkId(null)}
                                onDrop={(e) => { e.stopPropagation(); handleDrop(bookmark.id, "bookmark"); }}
                                onClick={(e) => showEditControls && (e.preventDefault(), openEditModal(bookmark, section.id))}
                                className={`glass ${showEditControls ? "edit-mode-lift" : "bookmark-hover-effect"}`} 
                                style={{ 
                                    display: 'flex', 
                                    alignItems: 'center', 
                                    gap: '0.75rem', 
                                    padding: '0.75rem', 
                                    textDecoration: 'none', 
                                    borderRadius: '10px',
                                    background: dragOverBookmarkId === bookmark.id && dragType.current === "bookmark" ? 'rgba(var(--primary-rgb), 0.4)' : 'rgba(var(--primary-rgb), var(--glass-opacity))',
                                    borderColor: dragOverBookmarkId === bookmark.id && dragType.current === "bookmark" ? 'var(--primary)' : 'rgba(var(--primary-rgb), 0.15)',
                                    border: '1px solid rgba(var(--primary-rgb), 0.2)',
                                    borderTop: dragOverBookmarkId === bookmark.id && dragType.current === "bookmark" && dragOverSide === "top" ? '2px solid var(--primary)' : '1px solid rgba(var(--primary-rgb), 0.2)',
                                    borderBottom: dragOverBookmarkId === bookmark.id && dragType.current === "bookmark" && dragOverSide === "bottom" ? '2px solid var(--primary)' : 'none',
                                    transition: 'all 0.2s ease',
                                    boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                                }}>
                                <div style={{ width: `${iconSize + 4}px`, height: `${iconSize + 4}px`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                  <IconComponent name={bookmark.icon || "Bookmark"} size={iconSize} />
                                </div>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <h3 style={{ fontSize: '0.95rem', margin: 0 }}>{bookmark.title}</h3>
                                  {bookmark.description && <p style={{ fontSize: '0.8rem', opacity: 0.4, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis' }}>{bookmark.description}</p>}
                                </div>
                                {showEditControls && <button onClick={async (e) => { e.preventDefault(); e.stopPropagation(); await actions.createBookmark({ ...bookmark, id: undefined, sectionId: section.id, order: bookmark.order + 1 } as any); window.location.reload(); }} className="btn" style={{ padding: '4px' }}><Copy size={12} /></button>}
                            </a>
                          ))}
                        </div>
                      )}
                      {showEditControls && !collapsedSections[section.id] && (
                        <div style={{ position: 'relative', height: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <div 
                            onMouseDown={(e) => handleResizeStart(e, section.id, section.height || 120)}
                            style={{ 
                              height: '100%', width: '60px', cursor: 'ns-resize', 
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              opacity: resizingId === section.id ? 1 : 0.3, transition: 'all 0.2s'
                            }}
                          >
                              <div style={{ width: '30px', height: '3px', background: 'var(--primary)', borderRadius: '2px' }} />
                          </div>
                          
                          {section.height && (
                            <button 
                              onClick={async () => {
                                setTabs(prev => prev.map(t => t.id === activeTabId ? { ...t, sections: t.sections.map(s => s.id === section.id ? { ...s, height: null } : s) } : t));
                                await actions.updateSectionLayout(section.id, activeTabId, { height: null });
                              }}
                              className="glass" 
                              style={{ position: 'absolute', right: '0.5rem', padding: '2px', borderRadius: '4px', cursor: 'pointer', opacity: 0.4 }}
                              title="Reset to Auto Height"
                            >
                              <Maximize2 size={10} />
                            </button>
                          )}
                        </div>
                      )}
                  </div>
                ))}
                {showEditControls && (
                  <button 
                    onClick={() => { setTargetColumnForNewSection(colIdx); setEditingSectionForModal(null); setIsSectionModalOpen(true); }}
                    onDragOver={(e) => handleDragOver(e, colIdx.toString(), "column")}
                    onDrop={() => handleDrop(colIdx.toString(), "column")}
                    className="glass"
                    style={{ 
                        padding: '1rem', 
                        borderRadius: '14px', 
                        border: dragOverColIdx === colIdx && dragType.current === "section" && !dragOverSectionId ? '2px solid var(--primary)' : '1px solid var(--glass-border)', 
                        background: dragOverColIdx === colIdx && dragType.current === "section" && !dragOverSectionId ? 'rgba(var(--primary-rgb), 0.2)' : 'transparent', 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center', 
                        gap: '0.5rem', 
                        opacity: dragOverColIdx === colIdx ? 1 : 0.5, 
                        transition: 'all 0.3s ease', 
                        cursor: 'pointer', 
                        color: 'var(--text)'
                    }}
                  >
                    <Plus size={18} />
                    <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>Add Section</span>
                  </button>
                )}
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>

      <style jsx global>{`
        body { background: var(--bg-gradient) fixed; margin: 0; min-height: 100vh; color: var(--text); }
        .glass { background: var(--glass-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 12px; }
        .btn { border: none; cursor: pointer; transition: all 0.2s; display: flex; alignItems: center; justifyContent: center; }
        .btn-primary { background: var(--primary); color: var(--nav-text) !important; }
        .edit-mode-lift { cursor: grab; transition: transform 0.2s; }
        .edit-mode-lift:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,0.2); }
        .bookmark-hover-effect:hover { 
            border-color: var(--primary) !important; 
            background: rgba(var(--primary-rgb), 0.32) !important; 
            transform: translateY(-3px); 
            box-shadow: 0 12px 32px rgba(0,0,0,0.18);
        }
      `}</style>

      {/* Modals */}
      {isModalOpen && (
        <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: resolvedTheme === 'light' ? 'rgba(255,255,255,0.45)' : 'rgba(0,0,0,0.6)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div className="glass glass-card" style={{ width: '100%', maxWidth: '500px', padding: '2.5rem', maxHeight: '95vh', overflowY: 'auto', border: '1px solid var(--glass-border)', boxShadow: '0 25px 50px rgba(0,0,0,0.25)' }}>
            <h2 style={{ marginBottom: '1.5rem' }}>{modalMode === "add" ? "Add Bookmark" : "Edit Bookmark"}</h2>
            <form action={async (formData) => {
                const data = { title: formData.get("title") as string, url: formData.get("url") as string, description: formData.get("description") as string, icon: liveIconPreview || "", openInNewTab: formData.get("newTab") === "on", sectionId: targetSectionId, order: 0 };
                if (modalMode === "add") await actions.createBookmark(data); else await actions.updateBookmark(editingBookmark!.id, data);
                window.location.reload();
            }} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <input name="title" defaultValue={editingBookmark?.title} placeholder="Title" className="glass" style={{ padding: '0.75rem' }} required />
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <input ref={bookmarkUrlRef} name="url" defaultValue={editingBookmark?.url} placeholder="URL (https://...)" className="glass" style={{ flex: 1, padding: '0.75rem' }} required />
                    <button type="button" onClick={handleFetchFavicon} className="btn glass" style={{ padding: '0 1rem', borderRadius: '10px' }} title="Pull Favicon">
                        <Download size={18} />
                    </button>
                </div>
                <textarea name="description" defaultValue={editingBookmark?.description || ""} placeholder="Description" className="glass" style={{ padding: '0.75rem' }} />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.5rem' }}>
                    <input type="checkbox" name="newTab" defaultChecked={editingBookmark ? editingBookmark.openInNewTab : true} style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: 'var(--primary)' }} />
                    <span style={{ fontSize: '0.85rem', fontWeight: 600, opacity: 0.7 }}>Open in New Tab</span>
                </div>
                <IconPicker currentIcon={liveIconPreview} setIcon={setLiveIconPreview} query={iconSearchQuery} setQuery={setIconSearchQuery} iconRegistry={iconRegistry} onUpload={handlePickerUpload} />
                <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
                    <button onClick={() => setIsModalOpen(false)} type="button" className="btn glass" style={{ flex: 1, padding: '1rem', fontWeight: 600 }}>Cancel</button>
                    <button type="submit" className="btn btn-primary" style={{ flex: 2, padding: '1rem', fontWeight: 700 }}>Save Changes</button>
                </div>
            </form>
          </div>
        </div>
      )}

      {isTabModalOpen && (
        <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: resolvedTheme === 'light' ? 'rgba(255,255,255,0.45)' : 'rgba(0,0,0,0.6)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div className="glass glass-card" style={{ width: '100%', maxWidth: '400px', padding: '2.5rem', border: '1px solid var(--glass-border)', boxShadow: '0 25px 50px rgba(0,0,0,0.25)' }}>
            <h2>{editingTabForModal ? "Edit Tab" : "Add Tab"}</h2>
            <form action={async (formData) => {
              const title = formData.get("title") as string;
              if (editingTabForModal) await actions.updateTab(editingTabForModal.id, { title, icon: liveIconPreview });
              else await actions.createTab({ title, icon: liveIconPreview || "" });
              window.location.reload();
            }}>
              <input name="title" defaultValue={editingTabForModal?.title} placeholder="Tab Name" className="glass" style={{ width: '100%', padding: '0.75rem', marginBottom: '1rem' }} required />
              <IconPicker currentIcon={liveIconPreview} setIcon={setLiveIconPreview} query={iconSearchQuery} setQuery={setIconSearchQuery} iconRegistry={iconRegistry} onUpload={handlePickerUpload} />
              <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
                <button onClick={() => setIsTabModalOpen(false)} type="button" className="btn glass" style={{ flex: 1, padding: '1rem', fontWeight: 600 }}>Cancel</button>
                <button type="submit" className="btn btn-primary" style={{ flex: 2, padding: '1rem', fontWeight: 700 }}>Save Tab</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isSectionModalOpen && (
        <div className="modal-overlay" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: resolvedTheme === 'light' ? 'rgba(255,255,255,0.45)' : 'rgba(0,0,0,0.6)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div className="glass glass-card" style={{ width: '100%', maxWidth: '450px', padding: '2.5rem', border: '1px solid var(--glass-border)', boxShadow: '0 25px 50px rgba(0,0,0,0.25)' }}>
            <h2>{editingSectionForModal ? "Edit Section" : "Add Section"}</h2>
            <form action={async (formData) => {
              const title = formData.get("title") as string;
              const isAuto = formData.get("autoHeight") === "on";
              
              if (editingSectionForModal) {
                  await actions.updateSection(editingSectionForModal.id, { title, icon: liveIconPreview });
                  if (isAuto) await actions.updateSectionLayout(editingSectionForModal.id, activeTabId, { height: null });
              } else {
                  const newSec = await actions.createSection({ title, icon: liveIconPreview || "" });
                  await actions.addSectionToTab(newSec.id, activeTabId, targetColumnForNewSection);
                  // Default to auto height for new sections
              }
              window.location.reload();
            }}>
              <input name="title" defaultValue={editingSectionForModal?.title} placeholder="Section Title" className="glass" style={{ width: '100%', padding: '0.75rem', marginBottom: '1rem' }} required />
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.25rem', padding: '0.75rem', borderRadius: '10px', background: 'rgba(255,255,255,0.03)' }}>
                 <input 
                    type="checkbox" 
                    name="autoHeight" 
                    id="auto-height-check"
                    defaultChecked={!editingSectionForModal?.height} 
                 />
                 <label htmlFor="auto-height-check" style={{ fontSize: '0.85rem', cursor: 'pointer', flex: 1 }}>
                    Auto-expand height to fit content
                 </label>
              </div>

              <IconPicker currentIcon={liveIconPreview} setIcon={setLiveIconPreview} query={iconSearchQuery} setQuery={setIconSearchQuery} iconRegistry={iconRegistry} onUpload={handlePickerUpload} />
              
              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem', flexWrap: 'wrap' }}>
                <button onClick={() => setIsSectionModalOpen(false)} type="button" className="btn glass" style={{ flex: 1, padding: '1rem', minWidth: '100px', fontWeight: 600 }}>Cancel</button>
                {editingSectionForModal && (
                  <button 
                    type="button" 
                    onClick={async () => { if(confirm('Delete section?')) { await actions.deleteSection(editingSectionForModal.id); window.location.reload(); } }}
                    className="btn glass" 
                    style={{ flex: 1, padding: '1rem', minWidth: '100px', background: 'rgba(239, 68, 68, 0.1)', color: '#ff4444', fontWeight: 600 }}
                  >
                    <Trash2 size={16} style={{ marginRight: '0.5rem' }} /> Delete
                  </button>
                )}
                <button type="submit" className="btn btn-primary" style={{ flex: 2, padding: '1rem', minWidth: '150px', fontWeight: 700 }}>Save Section</button>
              </div>
            </form>
          </div>
        </div>
      )}
        {/* --- SECTION CATALOG MODAL --- */}
        {isLibraryOpen && (
           <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(15px)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
              <div className="glass" style={{ width: '100%', maxWidth: '1000px', maxHeight: '85vh', borderRadius: '32px', display: 'flex', flexDirection: 'column', overflow: 'hidden', boxShadow: '0 30px 60px rgba(0,0,0,0.4)', border: '1px solid var(--glass-border)' }}>
                 <div style={{ padding: '2rem', borderBottom: '1px solid var(--glass-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                       <h2 style={{ fontSize: '1.75rem', fontWeight: 800, margin: 0 }}>Section Catalog</h2>
                       <p style={{ margin: '0.25rem 0 0 0', opacity: 0.5, fontSize: '0.9rem' }}>These sections are available for you to import into your workspace.</p>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
                        <div className="glass" style={{ position: 'relative', width: '300px' }}>
                            <Search size={16} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', opacity: 0.3 }} />
                            <input 
                                value={catalogSearchQuery}
                                onChange={(e) => setCatalogSearchQuery(e.target.value)}
                                placeholder="Search sections or tool urls..."
                                className="glass"
                                style={{ width: '100%', padding: '0.6rem 1rem 0.6rem 2.8rem', borderRadius: '12px', fontSize: '0.85rem', border: 'none' }}
                            />
                        </div>
                        <button onClick={() => setIsLibraryOpen(false)} style={{ background: 'rgba(255,255,255,0.05)', border: 'none', padding: '0.6rem', borderRadius: '50%', cursor: 'pointer', color: 'var(--text)' }}><X size={24} /></button>
                    </div>
                 </div>

                 <div style={{ flex: 1, overflowY: 'auto', padding: '2rem', display: 'flex', flexDirection: 'column', gap: '3rem' }}>
                    {/* Modular Toolsets Section */}
                    <section>
                       <h3 style={{ fontSize: '0.75rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em', opacity: 0.4, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                          <Grid size={14} /> Available Sections
                       </h3>
                       <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1.5rem' }}>
                          {librarySections
                            .filter((ls: any) => {
                                const q = catalogSearchQuery.toLowerCase();
                                if (!q) return true;
                                return ls.title.toLowerCase().includes(q) || 
                                       ls.bookmarks.some((b: any) => 
                                          b.title.toLowerCase().includes(q) || 
                                          b.url.toLowerCase().includes(q)
                                       );
                            })
                            .map((ls: any) => {
                             const isAlreadyInTab = activeTab?.sections.some(s => s.id === ls.id);
                             return (
                                <div key={ls.id} className="glass" style={{ padding: '1.5rem', borderRadius: '24px', position: 'relative', overflow: 'hidden', border: '1px solid var(--glass-border)', display: 'flex', flexDirection: 'column', gap: '1rem', transition: 'all 0.3s' }}>
                                   {justImportedId === ls.id && (
                                      <div style={{ position: 'absolute', inset: 0, background: 'rgba(74, 222, 128, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10, backdropFilter: 'blur(4px)', animation: 'pulse 1s ease' }}>
                                         <Check size={48} color="#4ade80" />
                                      </div>
                                   )}
                                   <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                      <div style={{ width: '48px', height: '48px', borderRadius: '14px', background: 'rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)' }}>
                                         <IconComponent name={ls.icon || "LayoutGrid"} size={24} />
                                      </div>
                                      <div>
                                         <h4 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 700 }}>{ls.title}</h4>
                                         <span style={{ fontSize: '0.7rem', opacity: 0.5, fontWeight: 600 }}>{ls.organization || "Global"} Toolset</span>
                                      </div>
                                   </div>
                                   <p style={{ fontSize: '0.85rem', opacity: 0.6, margin: 0, minHeight: '3rem' }}>{ls.description || "A curated cluster of tools to boost your workflow."}</p>
                                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                                      {ls.bookmarks.slice(0, 3).map((b: any) => (
                                         <span key={b.id} style={{ fontSize: '0.65rem', padding: '0.2rem 0.5rem', borderRadius: '6px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--glass-border)' }}>
                                            {b.title}
                                         </span>
                                      ))}
                                      {ls.bookmarks.length > 3 && <span style={{ fontSize: '0.65rem', opacity: 0.3 }}>+{ls.bookmarks.length-3} more</span>}
                                   </div>
                                   <button 
                                      disabled={isAlreadyInTab || importingSectionId === ls.id}
                                      onClick={async () => {
                                         if (!activeTabId) return;
                                         setImportingSectionId(ls.id);
                                         try {
                                            await actions.addSectionToTab(ls.id, activeTabId, 0);
                                            // Optimistically update tabs state with required layout properties
                                            const shapedSection = {
                                                ...ls,
                                                column: 0,
                                                height: null,
                                                tabId: activeTabId
                                            };
                                            
                                            setTabs(prev => prev.map(t => t.id === activeTabId ? {
                                                ...t,
                                                sections: [...t.sections, shapedSection]
                                            } : t));
                                            
                                            setJustImportedId(ls.id);
                                            setTimeout(() => setJustImportedId(null), 2000);
                                         } finally {
                                            setImportingSectionId(null);
                                         }
                                      }}
                                      className="btn btn-primary" 
                                      style={{ 
                                         marginTop: 'auto',
                                         padding: '0.75rem', borderRadius: '12px', fontWeight: 700, fontSize: '0.85rem',
                                         background: (isAlreadyInTab || justImportedId === ls.id) ? 'rgba(74, 222, 128, 0.1)' : 'var(--primary)',
                                         color: (isAlreadyInTab || justImportedId === ls.id) ? '#4ade80' : 'var(--nav-text)',
                                         border: (isAlreadyInTab || justImportedId === ls.id) ? '1px solid #4ade80' : 'none',
                                         display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem'
                                      }}
                                   >
                                      {importingSectionId === ls.id ? (
                                         <>
                                            <div className="animate-spin" style={{ width: '14px', height: '14px', border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%' }} />
                                            Adding...
                                         </>
                                      ) : isAlreadyInTab || justImportedId === ls.id ? (
                                         <>
                                            <Check size={14} />
                                            {justImportedId === ls.id ? "Added!" : "In Dashboard"}
                                         </>
                                      ) : `Add to ${activeTab?.title}`}
                                   </button>
                                </div>
                             );
                          })}
                          {librarySections.length === 0 && (
                             <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '3rem', opacity: 0.5 }}>
                                <Library size={48} style={{ marginBottom: '1rem', opacity: 0.2 }} />
                                <p>No shared toolsets are currently available in the catalog.</p>
                             </div>
                          )}
                       </div>
                    </section>
                 </div>
              </div>
           </div>
        )}
    </>
  );
}
